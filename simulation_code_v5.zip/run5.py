"""v5 experiments: robustness of value-of-information results across layouts, order sizes,
storage and forklift placement; search-time penalty for wrong-slot picks; UWB NLOS sensitivity."""
import json, sys, time
import numpy as np
sys.path.insert(0, "/home/claude/work")
from model3 import *
from model2 import abc_popularity, sample_order, anchor_sets, scaled_layout, case_layout
from model import held_karp, held_karp_path, route_len

rng = np.random.default_rng(20261123)
OUT = {}

def misplaced(L, i, m):
    if rng.random() >= m:
        return i
    ax, y = L.LOCS[i]
    cand = [j for j in range(len(L.LOCS)) if j != i and abs(L.LOCS[j][0] - ax) < 1e-6 and abs(L.LOCS[j][1] - y) <= 12]
    return int(rng.choice(cand)) if cand else i

def execute(L, seq, rec, true_idx, start):
    tot, cur, fails = 0.0, start, 0
    for k in seq:
        r = tuple(L.LOCS[rec[k]]); t = tuple(L.LOCS[true_idx[k]])
        tot += L.dist(cur, r); cur = r
        if rec[k] != true_idx[k]:
            tot += L.dist(cur, t); cur = t; fails += 1
    return tot + L.dist(cur, tuple(L.dock)), fails

def plan(L, rec, starts, fixed=None):
    n = len(rec)
    pts = [tuple(L.LOCS[i]) for i in rec] + list(starts) + [tuple(L.dock)]
    D = L.dmat(pts); end = n + len(starts)
    best = None
    for f in ([fixed] if fixed is not None else range(len(starts))):
        sq = held_karp_path(D, n + f, list(range(n)), end); l = route_len(D, n + f, sq, end)
        if best is None or l < best[0]:
            best = (l, f, sq)
    return best[1], best[2]

def ci(a):
    a = np.asarray(a); return float(1.96 * a.std(ddof=1) / np.sqrt(len(a)))

# ---------------- R. robustness grid ----------------
t0 = time.time()
CASE = case_layout()
LAYS = {"7x3 (case)": CASE, "14x3": scaled_layout(14, 3), "28x6": scaled_layout(28, 6)}
cells = [("7x3 (case)", n) for n in (4, 8, 12)] + [("14x3", 8), ("28x6", 8)]
COND = [("Perfect", "Exact"), ("Perfect", "None"), ("Records 5%", "Exact"), ("Records 5%", "None")]
ROB = {}; NO = 200
for lay, n in cells:
    L = LAYS[lay]; nloc = len(L.LOCS); kf = 6 if lay == "28x6" else 3
    for stor in ("random", "class"):
        prob = abc_popularity(nloc, rng, stor, L)
        for place in ("staged", "dispersed"):
            res = {c: [] for c in COND}
            for o in range(NO):
                idx = list(sample_order(n, prob, rng))
                if place == "dispersed":
                    fl = [tuple(L.LOCS[i]) for i in rng.choice(nloc, kf, replace=False)]
                elif L.park is not None:
                    fl = [(rng.uniform(*L.park[0]), rng.uniform(*L.park[1])) for _ in range(kf)]
                else:
                    fl = [(rng.uniform(L.A[0], L.A[-1]), L.C[0]) for _ in range(kf)]
                centre = ((L.park[0][0] + L.park[0][1]) / 2, (L.park[1][0] + L.park[1][1]) / 2) if L.park is not None else tuple(L.dock)
                pts = [tuple(L.LOCS[i]) for i in idx] + fl + [tuple(L.dock)]
                D = L.dmat(pts); opt = min(held_karp(D, n + f, list(range(n)), n + kf) for f in range(kf))
                recs = {"Perfect": idx, "Records 5%": [misplaced(L, i, .05) for i in idx]}
                for s, fc in COND:
                    if fc == "Exact":
                        f, sq = plan(L, recs[s], fl)
                    else:
                        f, sq = plan(L, recs[s], [centre] * kf, fixed=o % kf)
                    ex, _ = execute(L, sq, recs[s], idx, fl[f])
                    res[(s, fc)].append(100 * (ex - opt) / opt)
            ROB[f"{lay}|{n}|{stor}|{place}"] = {f"{s}|{fc}": dict(excess=float(np.mean(v)), ci=ci(v)) for (s, fc), v in res.items()}
            print(lay, n, stor, place, {k: round(x["excess"], 1) for k, x in ROB[f"{lay}|{n}|{stor}|{place}"].items()}, flush=True)
OUT["ROB"] = ROB
print("R", round(time.time() - t0), flush=True)

# ---------------- S. search-time penalty and NLOS sensitivity (case layout, class storage, dispersed, n = 8) ----------------
t0 = time.time()
L = CASE; nloc = len(L.LOCS); AS = anchor_sets(L)
prob = abc_popularity(nloc, rng, "class", L)
A4 = np.c_[AS["4 corners"], np.full(4, 3.3)]
def uwb_slot(i, beta):
    r, _ = sim_ranges3d(L, A4, np.array([*L.SLOTS[i], rng.choice(LEVELS)]), rng, 0.33, beta)
    q = locate2d_from3d(r, A4, 5.0)
    return int(np.argmin(np.linalg.norm(L.SLOTS - q, axis=1)))
SC = ["Perfect", "UWB β=0.15", "UWB β=0.3", "UWB β=0.6", "Records 2%", "Records 5%", "Records 10%"]
raw = {s: [] for s in SC}; n = 8; V = 5.0; PEN = [0, 30, 60]
for o in range(300):
    idx = list(sample_order(n, prob, rng))
    fl = [tuple(L.LOCS[i]) for i in rng.choice(nloc, 3, replace=False)]
    pts = [tuple(L.LOCS[i]) for i in idx] + fl + [tuple(L.dock)]
    D = L.dmat(pts); opt = min(held_karp(D, n + f, list(range(n)), n + 3) for f in range(3))
    recs = {"Perfect": idx, "UWB β=0.15": [uwb_slot(i, .15) for i in idx], "UWB β=0.3": [uwb_slot(i, .3) for i in idx],
            "UWB β=0.6": [uwb_slot(i, .6) for i in idx], "Records 2%": [misplaced(L, i, .02) for i in idx],
            "Records 5%": [misplaced(L, i, .05) for i in idx], "Records 10%": [misplaced(L, i, .10) for i in idx]}
    for s in SC:
        f, sq = plan(L, recs[s], fl)
        ex, fails = execute(L, sq, recs[s], idx, fl[f])
        raw[s].append((opt, ex, fails))
SEARCH = {}
for s in SC:
    a = np.array(raw[s]); topt = a[:, 0] / V
    SEARCH[s] = {"fail_share": float(100 * a[:, 2].mean() / n)}
    for p_ in PEN:
        t = (a[:, 1] / V + p_ * a[:, 2] - topt) / topt * 100
        SEARCH[s][str(p_)] = dict(excess=float(t.mean()), ci=ci(t))
OUT["SEARCH"] = SEARCH
print({s: (round(SEARCH[s]["fail_share"], 1), [round(SEARCH[s][str(p)]["excess"], 1) for p in PEN]) for s in SC})
print("S", round(time.time() - t0), flush=True)
json.dump(OUT, open("/home/claude/work/results5.json", "w"), indent=1)
