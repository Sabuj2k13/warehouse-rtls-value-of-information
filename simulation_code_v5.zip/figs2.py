import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.spines.top": False,
                     "axes.spines.right": False, "axes.edgecolor": "#888", "axes.labelcolor": "#222",
                     "xtick.color": "#444", "ytick.color": "#444", "savefig.dpi": 300})
C = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#6250d6"]
R = json.load(open("/home/claude/work/results2.json"))

# Fig 3: excess by policy, order size, storage (small multiples, shared y)
sizes = [4, 6, 8, 10, 12]
pols = ["Random", "S-shape", "Largest gap", "Nearest neighbour", "NN + 2-opt", "Optimal"]
lab = {"Random": "Unsupported (random)", "S-shape": "S-shape type", "Largest gap": "Largest-gap type",
       "Nearest neighbour": "Nearest neighbour", "NN + 2-opt": "NN + 2-opt", "Optimal": "Optimal route, nearest forklift"}
titles = {"uniform": "(a) Uniform demand", "random": "(b) ABC, random storage", "class": "(c) ABC, class-based storage"}
fig, axs = plt.subplots(1, 3, figsize=(7.2, 3.0), sharey=True)
for a, st in zip(axs, ["uniform", "random", "class"]):
    for i, p in enumerate(pols):
        m = [R["E1"][f"{st}|{n}"][p]["excess"] for n in sizes]
        a.plot(sizes, m, color=C[i], lw=1.8, marker="o", ms=3.5, label=lab[p])
    a.set_title(titles[st], fontsize=8.5, loc="left"); a.set_xticks(sizes)
    a.grid(axis="y", color="#eee", lw=0.6); a.set_xlabel("Order size (lines)")
axs[0].set_ylabel("Excess travel over joint optimum (%)")
h, l = axs[0].get_legend_handles_labels()
fig.legend(h, l, loc="lower center", ncol=3, frameon=False, fontsize=7.5, bbox_to_anchor=(0.5, -0.02))
fig.tight_layout(rect=(0, 0.12, 1, 1)); fig.savefig("/home/claude/work/v2_fig3_policies.png"); plt.close(fig)

# Fig 4: value of joint forklift selection by layout and fleet
keys = [("7x3", "Case size\n7 aisles × 3 blocks"), ("14x3", "14 × 3"), ("14x6", "14 × 6"), ("28x6", "28 × 6")]
fig, ax = plt.subplots(figsize=(6.2, 3.0))
x = np.arange(len(keys)); w = 0.36
for j, kf in enumerate([3, 6]):
    g = [R["E2"][f"{k}|{kf}"]["gain"] for k, _ in keys]; ci = [R["E2"][f"{k}|{kf}"]["ci"] for k, _ in keys]
    bars = ax.bar(x + (j - 0.5) * (w + 0.02), g, w, yerr=ci, color=C[j], capsize=2, label=f"{kf} forklifts",
                  error_kw=dict(lw=0.8, ecolor="#555"))
    for xi, gi, cc in zip(x + (j - 0.5) * (w + 0.02), g, ci):
        ax.text(xi, gi + cc + 0.12, f"{gi:.1f}", ha="center", fontsize=7.5, color="#333")
ax.set_xticks(x); ax.set_xticklabels([k[1] for k in keys], fontsize=8)
ax.set_ylabel("Travel saved by joint selection (%)"); ax.set_ylim(0, 5.6)
ax.grid(axis="y", color="#eee", lw=0.6); ax.legend(frameon=False, fontsize=8, loc="upper left")
ax.set_xlabel("Layout (picking aisles × blocks); forklifts dispersed in the aisles")
fig.tight_layout(); fig.savefig("/home/claude/work/v2_fig4_fleet.png"); plt.close(fig)

# Fig 5: slot identification by anchor configuration and NLOS severity (NLS estimator)
cfg = ["3 corners", "4 corners", "6 (corners + mid-walls)", "8 (perimeter)", "9 (cross-aisle grid)"]
cl = ["3\ncorners", "4\ncorners", "6\ncorners+walls", "8\nperimeter", "9\ncross-aisle grid"]
fig, ax = plt.subplots(figsize=(6.2, 3.0))
x = np.arange(len(cfg)); w = 0.26
for j, nm in enumerate([0.2, 0.4, 0.8]):
    v = [R["E3"][f"{nm}|{c}|NLS"]["slot"] for c in cfg]
    ax.bar(x + (j - 1) * (w + 0.02), v, w, color=["#86b6ef", "#2a78d6", "#184f95"][j],
           label=f"{nm} ft" + (" (calibrated)" if nm == 0.4 else ""))
    for xi, vi in zip(x + (j - 1) * (w + 0.02), v):
        ax.text(xi, vi + 1.5, f"{vi:.0f}", ha="center", fontsize=7, color="#333")
ax.set_xticks(x); ax.set_xticklabels(cl, fontsize=8); ax.set_ylim(0, 104)
ax.set_ylabel("Pallets mapped to correct slot (%)"); ax.set_xlabel("UWB anchor configuration")
ax.grid(axis="y", color="#eee", lw=0.6); ax.legend(frameon=False, fontsize=7.2, loc="lower center", ncol=3, bbox_to_anchor=(0.5, 1.0), title="NLOS bias per rack row crossed", title_fontsize=7.5)
fig.tight_layout(); fig.savefig("/home/claude/work/v2_fig5_anchors.png"); plt.close(fig)
print("ok")
