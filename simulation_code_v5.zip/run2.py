import json, sys, time
import numpy as np
from scipy.stats import wilcoxon, friedmanchisquare
sys.path.insert(0, "/home/claude/work")
from model2 import *
from model import held_karp_path, route_len

rng = np.random.default_rng(20261120)
OUT = {}
L = case_layout()
nloc = len(L.LOCS)
POL = ["Random", "S-shape", "Largest gap", "Nearest neighbour", "NN + 2-opt", "Optimal", "Joint optimal"]

def park_forklifts(k=3):
    return [(rng.uniform(*L.park[0]), rng.uniform(*L.park[1])) for _ in range(k)]

# ---------------- E1: routing policies x storage x order size ----------------
t0 = time.time()
SIZES = [4, 6, 8, 10, 12]; NI = 300
STOR = ["uniform", "random", "class"]
E1 = {}
raw = {}
for st in STOR:
    prob = abc_popularity(nloc, rng, st, L)
    for n in SIZES:
        rows = []
        for _ in range(NI):
            idx = sample_order(n, prob, rng)
            rows.append(all_policies(L, idx, park_forklifts(), rng))
        raw[(st, n)] = rows
        o = np.array([r["Joint optimal"] for r in rows])
        cell = {}
        for p in POL:
            v = np.array([r[p] for r in rows]); ex = 100 * (v - o) / o
            cell[p] = dict(mean=float(v.mean()), sd=float(v.std(ddof=1)), excess=float(ex.mean()),
                           ci=float(1.96 * ex.std(ddof=1) / np.sqrt(len(ex))))
        E1[f"{st}|{n}"] = cell
print("E1", round(time.time() - t0), "s")
OUT["E1"] = E1
# stats: Friedman across the 6 benchmark+optimal policies at n=8 class; Wilcoxon each vs joint optimal
st_tests = {}
for st in STOR:
    for n in SIZES:
        rows = raw[(st, n)]
        o = np.array([r["Joint optimal"] for r in rows])
        st_tests[f"{st}|{n}"] = {p: float(wilcoxon(np.array([r[p] for r in rows]), o, zero_method="zsplit").pvalue)
                                 for p in POL[:-1]}
OUT["wilcoxon_max_p"] = max(v for d in st_tests.values() for k, v in d.items() if k != "Optimal")
OUT["wilcoxon_optimal_vs_joint_max_p"] = max(d["Optimal"] for d in st_tests.values())
rows = raw[("class", 8)]
OUT["friedman_class8"] = float(friedmanchisquare(*[np.array([r[p] for r in rows]) for p in POL[:-1]]).pvalue)
# storage effect on optimal route length
OUT["storage_effect"] = {n: {st: float(np.mean([r["Joint optimal"] for r in raw[(st, n)]])) for st in STOR} for n in SIZES}

# ---------------- E2: when does forklift selection matter? scale ----------------
t0 = time.time()
E2 = {}
for na, nb in [(7, 3), (14, 3), (14, 6), (28, 6)]:
    LL = scaled_layout(na, nb)
    for kf in [3, 6]:
        g, ch, nr = [], [], []
        for _ in range(150):
            idx = rng.choice(len(LL.LOCS), 8, replace=False)
            fidx = rng.choice(len(LL.LOCS), kf, replace=False)   # forklifts dispersed at access points (mid-shift)
            fl = [tuple(LL.LOCS[i]) for i in fidx]
            pts = [tuple(LL.LOCS[i]) for i in idx] + fl + [tuple(LL.dock)]
            D = LL.dmat(pts); n = 8; end = n + kf
            fn = min(range(kf), key=lambda f: min(D[n + f, k] for k in range(n)))
            a = held_karp(D, n + fn, list(range(n)), end)
            b = min(held_karp(D, n + f, list(range(n)), end) for f in range(kf))
            g.append(100 * (a - b) / a); ch.append(a - b > 1e-6)
        E2[f"{na}x{nb}|{kf}"] = dict(aisles=na, blocks=nb, forklifts=kf, area=float(LL.W * (LL.C[-1] - LL.C[0])),
                                    gain=float(np.mean(g)), ci=float(1.96 * np.std(g, ddof=1) / np.sqrt(len(g))),
                                    p95=float(np.percentile(g, 95)), changed=float(100 * np.mean(ch)))
print("E2", round(time.time() - t0), "s")
OUT["E2"] = E2

# ---------------- E3: UWB anchor design ----------------
t0 = time.time()
SIG_LOS = 0.33
E3 = {}
AS = anchor_sets(L)
prob_c = abc_popularity(nloc, rng, "class", L)
orders = [(sample_order(8, prob_c, rng), park_forklifts()) for _ in range(120)]
for nm in [0.2, 0.4, 0.8]:
    for name, A in AS.items():
        for est in (["NLS", "Robust"] if len(A) >= 4 else ["NLS"]):
            def locate(p):
                r, _ = sim_ranges(L, A, np.asarray(p, float), rng, SIG_LOS, nm)
                return multilaterate(r, A)[1] if est == "NLS" else robust_multilaterate(r, A)
            # slot-level accuracy over all slots (2 draws each)
            err, ok = [], []
            for _ in range(2):
                for i, s in enumerate(L.SLOTS):
                    q = locate(s); err.append(np.linalg.norm(q - s))
                    ok.append(int(np.argmin(np.linalg.norm(L.SLOTS - q, axis=1))) == i)
            # routing on measured data, executed on true data (only for base NLOS scenario)
            exc = []
            if nm == 0.4:
                for idx, fl in orders:
                    obs = [int(np.argmin(np.linalg.norm(L.SLOTS - locate(L.SLOTS[i]), axis=1))) for i in idx]
                    flo = [tuple(locate(f)) for f in fl]
                    Dobs = L.dmat([tuple(L.LOCS[i]) for i in obs] + flo + [L.dock])
                    best = None
                    for f in range(3):
                        sq = held_karp_path(Dobs, 8 + f, list(range(8)), 11)
                        l = route_len(Dobs, 8 + f, sq, 11)
                        if best is None or l < best[0]:
                            best = (l, f, sq)
                    Dt = L.dmat([tuple(L.LOCS[i]) for i in idx] + list(fl) + [L.dock])
                    ex_ = route_len(Dt, 8 + best[1], best[2], 11)
                    opt = min(held_karp(Dt, 8 + f, list(range(8)), 11) for f in range(3))
                    exc.append(100 * (ex_ - opt) / opt)
            E3[f"{nm}|{name}|{est}"] = dict(nlos=nm, anchors=name, n_anchors=len(A), est=est,
                                           rmse=float(np.sqrt(np.mean(np.square(err)))), p90=float(np.percentile(err, 90)),
                                           slot=float(100 * np.mean(ok)),
                                           excess=float(np.mean(exc)) if exc else None,
                                           excess_ci=float(1.96 * np.std(exc, ddof=1) / np.sqrt(len(exc))) if exc else None)
        print(" E3", nm, name, round(time.time() - t0), "s", flush=True)
OUT["E3"] = E3
json.dump(OUT, open("/home/claude/work/results2.json", "w"), indent=1)
print("done")
