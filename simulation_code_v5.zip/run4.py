"""v4 experiments: value-of-information grid, storage x routing additivity, large orders,
dispatching rules, pilot statistics (bootstrap, beta fit), convergence, hardware."""
import json, sys, time, platform, os
import numpy as np
sys.path.insert(0, "/home/claude/work")
from model3 import *
from model2 import abc_popularity, sample_order, anchor_sets
from model import held_karp, held_karp_path, route_len, nearest_neighbour, two_opt, mtz_ilp, multilaterate

rng = np.random.default_rng(20261122)
OUT = {}
L = case_layout(); nloc = len(L.LOCS); AS = anchor_sets(L)
prob_c = abc_popularity(nloc, rng, "class", L)
PARK_C = ((L.park[0][0] + L.park[0][1]) / 2, (L.park[1][0] + L.park[1][1]) / 2)
BETA, HA, HBAR = 0.3, 3.3, 5.0
A4 = np.c_[AS["4 corners"], np.full(4, HA)]
A3 = np.c_[AS["3 corners"], np.full(3, HA)]

def uwb_slot(i, A):
    r, _ = sim_ranges3d(L, A, np.array([*L.SLOTS[i], rng.choice(LEVELS)]), rng, 0.33, BETA)
    q = locate2d_from3d(r, A, HBAR)
    return int(np.argmin(np.linalg.norm(L.SLOTS - q, axis=1)))

def uwb_point(p, A):
    r, _ = sim_ranges3d(L, A, np.array([*p, FORK_TAG_H]), rng, 0.33, BETA)
    return tuple(locate2d_from3d(r, A, FORK_TAG_H))

def misplaced(i, m):
    if rng.random() >= m:
        return i
    ax, y = L.LOCS[i]
    cand = [j for j in range(nloc) if j != i and abs(L.LOCS[j][0] - ax) < 1e-6 and abs(L.LOCS[j][1] - y) <= 12]
    return int(rng.choice(cand)) if cand else int(rng.integers(nloc))

def execute(seq, rec, true_idx, start):
    """Travel from the true start: to each recorded slot; if the pallet is not there, on to its true slot; then dock."""
    tot, cur, fails = 0.0, start, 0
    for k in seq:
        r = tuple(L.LOCS[rec[k]]); t = tuple(L.LOCS[true_idx[k]])
        tot += L.dist(cur, r); cur = r
        if rec[k] != true_idx[k]:
            tot += L.dist(cur, t); cur = t; fails += 1
    return tot + L.dist(cur, tuple(L.dock)), fails

def plan(rec, starts, fixed=None):
    """Joint optimal plan on recorded data; fixed = forklift index chosen by rotation (no forklift info)."""
    n = len(rec)
    pts = [tuple(L.LOCS[i]) for i in rec] + list(starts) + [tuple(L.dock)]
    D = L.dmat(pts); end = n + len(starts)
    cands = [fixed] if fixed is not None else range(len(starts))
    best = None
    for f in cands:
        sq = held_karp_path(D, n + f, list(range(n)), end); l = route_len(D, n + f, sq, end)
        if best is None or l < best[0]:
            best = (l, f, sq)
    return best[1], best[2]

# ---------------- A. value-of-information grid ----------------
t0 = time.time()
SLOTC = ["Perfect", "UWB (4 anchors)", "UWB (3 anchors)", "Records 2%", "Records 5%", "Records 10%"]
FORKC = ["Exact", "Stale", "None"]
NI = 300; n = 8
acc = {(s, f): {"ex": [], "fail": []} for s in SLOTC for f in FORKC}
for o in range(NI):
    idx = list(sample_order(n, prob_c, rng))
    fl = [tuple(L.LOCS[i]) for i in rng.choice(nloc, 3, replace=False)]           # dispersed forklifts
    pts = [tuple(L.LOCS[i]) for i in idx] + fl + [tuple(L.dock)]
    D = L.dmat(pts); opt = min(held_karp(D, n + f, list(range(n)), n + 3) for f in range(3))
    recs = {"Perfect": idx, "UWB (4 anchors)": [uwb_slot(i, A4) for i in idx], "UWB (3 anchors)": [uwb_slot(i, A3) for i in idx],
            "Records 2%": [misplaced(i, .02) for i in idx], "Records 5%": [misplaced(i, .05) for i in idx],
            "Records 10%": [misplaced(i, .10) for i in idx]}
    stale = [tuple(L.LOCS[rng.integers(nloc)]) if rng.random() < 0.5 else f for f in fl]   # half have moved since last update
    rot = o % 3
    for s in SLOTC:
        rec = recs[s]
        for fc in FORKC:
            if fc == "Exact":
                f, sq = plan(rec, fl)
            elif fc == "Stale":
                f, sq = plan(rec, stale)
            else:
                f, sq = plan(rec, [PARK_C, PARK_C, PARK_C], fixed=rot)
            ex, fails = execute(sq, rec, idx, fl[f])
            acc[(s, fc)]["ex"].append(100 * (ex - opt) / opt); acc[(s, fc)]["fail"].append(fails)
VOI = {}
for (s, fc), v in acc.items():
    e = np.array(v["ex"])
    VOI[f"{s}|{fc}"] = dict(excess=float(e.mean()), ci=float(1.96 * e.std(ddof=1) / np.sqrt(len(e))),
                            fails=float(np.mean(v["fail"])), fail_share=float(np.mean(v["fail"]) / n * 100))
OUT["VOI"] = VOI
print("A", round(time.time() - t0), flush=True)

# ---------------- B. storage x routing additivity ----------------
t0 = time.time()
ADD = {}
for n in [4, 8, 12]:
    cells = {}
    for st in ["random", "class"]:
        prob = abc_popularity(nloc, rng, st, L)
        S, O = [], []
        for _ in range(300):
            idx = sample_order(n, prob, rng)
            fl = [(rng.uniform(*L.park[0]), rng.uniform(*L.park[1])) for _ in range(3)]
            pts = [tuple(L.LOCS[i]) for i in idx] + fl + [tuple(L.dock)]
            D = L.dmat(pts)
            fn = min(range(3), key=lambda f: min(D[n + f, k] for k in range(n)))
            S.append(traversal_route(L, idx, fl[fn], "S-shape")[0])
            O.append(min(held_karp(D, n + f, list(range(n)), n + 3) for f in range(3)))
        cells[st] = (np.array(S), np.array(O))
    (Sr, Or), (Sc, Oc) = cells["random"], cells["class"]
    def stats(a, b, c, d):
        base = a.mean(); route = a.mean() - b.mean(); store = a.mean() - c.mean(); both = a.mean() - d.mean()
        return base, route, store, both, both - route - store
    point = stats(Sr, Or, Sc, Oc)
    bs = []
    for _ in range(2000):
        i = rng.integers(0, 300, 300); j = rng.integers(0, 300, 300)
        bs.append(stats(Sr[i], Or[i], Sc[j], Oc[j]))
    bs = np.array(bs)
    ADD[n] = dict(base=point[0], route=point[1], store=point[2], both=point[3], inter=point[4],
                  inter_lo=float(np.percentile(bs[:, 4], 2.5)), inter_hi=float(np.percentile(bs[:, 4], 97.5)))
OUT["ADD"] = ADD
print("B", round(time.time() - t0), flush=True)

# ---------------- C. large orders ----------------
def or_opt(D, s, seq, end):
    best, bl, improved = list(seq), route_len(D, s, seq, end), True
    while improved:
        improved = False
        for k in (1, 2, 3):
            for i in range(len(best) - k + 1):
                seg = best[i:i + k]; rest = best[:i] + best[i + k:]
                for j in range(len(rest) + 1):
                    if j == i:
                        continue
                    cand = rest[:j] + seg + rest[j:]
                    cl = route_len(D, s, cand, end)
                    if cl < bl - 1e-9:
                        best, bl, improved = cand, cl, True
                        break
                if improved: break
            if improved: break
    return best

t0 = time.time()
SC = {}
for n in [20, 30, 50, 80, 100]:
    rows = []
    for _ in range(10 if n <= 30 else 8):
        idx = sample_order(n, prob_c, rng)
        st = (rng.uniform(*L.park[0]), rng.uniform(*L.park[1]))
        pts = [tuple(L.LOCS[i]) for i in idx] + [st, tuple(L.dock)]
        D = L.dmat(pts); s, end = n, n + 1
        t1 = time.perf_counter(); nn = nearest_neighbour(D, s, list(range(n))); a = two_opt(D, s, nn, end); ta = time.perf_counter() - t1
        t1 = time.perf_counter(); b = or_opt(D, s, two_opt(D, s, a, end), end); tb = ta + time.perf_counter() - t1
        la, lb = route_len(D, s, a, end), route_len(D, s, b, end)
        t1 = time.perf_counter(); ms = min(route_len(D, s, or_opt(D, s, two_opt(D, s, list(rng.permutation(n)), end), end), end) for _ in range(5)); tm = time.perf_counter() - t1
        best = min(lb, ms)
        row = dict(nn2=la, oropt=lb, multi=ms, t_nn2=ta, t_oropt=tb, t_multi=tm)
        if n <= 30:
            from scipy.optimize import milp, LinearConstraint, Bounds
            t1 = time.perf_counter()
            # MTZ via HiGHS with a 60 s limit
            import model
            try:
                from scipy.optimize import milp
                val = None
                nodes = [s] + list(range(n)) + [end]
                arcs = [(i, j) for i in nodes for j in nodes if i != j and j != s and i != end and not (i == s and j == end)]
                na = len(arcs); nv = na + n; c = np.zeros(nv); c[:na] = [D[i, j] for i, j in arcs]
                from scipy.sparse import lil_matrix
                rows_, lb_, ub_ = [], [], []
                def add(co, lo, hi): rows_.append(co); lb_.append(lo); ub_.append(hi)
                add({a_: 1 for a_, (i, j) in enumerate(arcs) if i == s}, 1, 1)
                add({a_: 1 for a_, (i, j) in enumerate(arcs) if j == end}, 1, 1)
                for k in range(n):
                    add({a_: 1 for a_, (i, j) in enumerate(arcs) if j == k}, 1, 1)
                    add({a_: 1 for a_, (i, j) in enumerate(arcs) if i == k}, 1, 1)
                for a_, (i, j) in enumerate(arcs):
                    if i < n and j < n:
                        add({na + i: 1, na + j: -1, a_: n}, -np.inf, n - 1)
                Am = lil_matrix((len(rows_), nv))
                for r_, co in enumerate(rows_):
                    for v_, x_ in co.items(): Am[r_, v_] = x_
                integ = np.ones(nv); integ[na:] = 0; lo = np.zeros(nv); hi = np.ones(nv); lo[na:] = 1; hi[na:] = n
                res = milp(c, constraints=LinearConstraint(Am.tocsr(), lb_, ub_), integrality=integ, bounds=Bounds(lo, hi),
                           options={"time_limit": 60})
                row.update(milp=float(res.fun) if res.x is not None else None,
                           milp_gap=float(getattr(res, "mip_gap", np.nan) or 0) * 100, t_milp=time.perf_counter() - t1,
                           milp_status=int(res.status))
                if res.x is not None:
                    best = min(best, float(res.fun))
            except Exception as e:
                row.update(milp=None, err=str(e))
        row["best"] = best
        rows.append(row)
    SC[n] = dict(gap_nn2=float(np.mean([100 * (r["nn2"] - r["best"]) / r["best"] for r in rows])),
                 gap_oropt=float(np.mean([100 * (r["oropt"] - r["best"]) / r["best"] for r in rows])),
                 t_nn2=float(np.mean([r["t_nn2"] for r in rows])), t_oropt=float(np.mean([r["t_oropt"] for r in rows])),
                 milp_gap=float(np.mean([r.get("milp_gap", np.nan) for r in rows])) if n <= 30 else None,
                 t_milp=float(np.mean([r.get("t_milp", np.nan) for r in rows])) if n <= 30 else None,
                 milp_vs_best=float(np.mean([100 * (r["milp"] - r["best"]) / r["best"] for r in rows if r.get("milp")])) if n <= 30 else None,
                 count=len(rows))
    print(" C", n, round(time.time() - t0), flush=True)
OUT["SCALE"] = SC

# ---------------- D. dispatching rules ----------------
t0 = time.time()
DR = {k: [] for k in ["Nearest to any line", "Nearest to order centroid", "Round robin", "Random"]}
for o in range(300):
    idx = sample_order(8, prob_c, rng)
    fl = [tuple(L.LOCS[i]) for i in rng.choice(nloc, 3, replace=False)]
    pts = [tuple(L.LOCS[i]) for i in idx] + fl + [tuple(L.dock)]
    D = L.dmat(pts); hk = [held_karp(D, 8 + f, list(range(8)), 11) for f in range(3)]; opt = min(hk)
    cen = tuple(L.LOCS[idx].mean(axis=0))
    ch = {"Nearest to any line": min(range(3), key=lambda f: min(D[8 + f, k] for k in range(8))),
          "Nearest to order centroid": min(range(3), key=lambda f: abs(fl[f][0] - cen[0]) + abs(fl[f][1] - cen[1])),
          "Round robin": o % 3, "Random": int(rng.integers(3))}
    for k, f in ch.items():
        DR[k].append(100 * (hk[f] - opt) / opt)
OUT["DISPATCH"] = {k: dict(excess=float(np.mean(v)), ci=float(1.96 * np.std(v, ddof=1) / np.sqrt(len(v))),
                           share_opt=float(100 * np.mean(np.array(v) < 1e-9))) for k, v in DR.items()}
print("D", round(time.time() - t0), flush=True)

# ---------------- E/F. pilot statistics ----------------
R1 = json.load(open("/home/claude/work/results.json"))
errs = np.array([r["err_nls"] for r in R1["case_loc"]["rows"]]); pal = errs[:4]
bs = [np.sqrt(np.mean(np.square(rng.choice(errs, len(errs))))) for _ in range(10000)]
bsp = [np.sqrt(np.mean(np.square(rng.choice(pal, 4)))) for _ in range(10000)]
OUT["PILOT"] = dict(rmse=float(np.sqrt(np.mean(errs ** 2))), ci=[float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5))],
                    pal_rmse=float(np.sqrt(np.mean(pal ** 2))), pal_ci=[float(np.percentile(bsp, 2.5)), float(np.percentile(bsp, 97.5))])
pilot_pal = [(15, 20.8), (15, 47.6), (45, 47.6), (7.5, 75.4)]
curve = {}
for hname, ha in [("low", 3.3), ("ceiling", 18.0)]:
    A = np.c_[AS["3 corners"], np.full(3, ha)]; xs, ys = [], []
    for b in np.arange(0.05, 0.71, 0.05):
        e = []
        for _ in range(250):
            for s in pilot_pal:
                r, _ = sim_ranges3d(L, A, np.array([*s, rng.choice(LEVELS)]), rng, 0.33, b)
                e.append(np.linalg.norm(locate2d_from3d(r, A, HBAR) - np.array(s)))
        xs.append(float(b)); ys.append(float(np.sqrt(np.mean(np.square(e)))))
    ys_m = np.maximum.accumulate(ys)
    inv = lambda v: float(np.interp(v, ys_m, xs))
    curve[hname] = dict(beta=xs, rmse=ys, beta_hat=inv(OUT["PILOT"]["pal_rmse"]),
                        beta_lo=inv(OUT["PILOT"]["pal_ci"][0]), beta_hi=inv(OUT["PILOT"]["pal_ci"][1]))
OUT["BETAFIT"] = curve
print("F done", flush=True)

# ---------------- G. convergence ----------------
ex_s, ex_n = [], []
for _ in range(1000):
    idx = sample_order(8, prob_c, rng)
    fl = [(rng.uniform(*L.park[0]), rng.uniform(*L.park[1])) for _ in range(3)]
    pts = [tuple(L.LOCS[i]) for i in idx] + fl + [tuple(L.dock)]
    D = L.dmat(pts); opt = min(held_karp(D, 8 + f, list(range(8)), 11) for f in range(3))
    fn = min(range(3), key=lambda f: min(D[8 + f, k] for k in range(8)))
    ex_s.append(100 * (traversal_route(L, idx, fl[fn], "S-shape")[0] - opt) / opt)
    ex_n.append(100 * (route_len(D, 8 + fn, nearest_neighbour(D, 8 + fn, list(range(8))), 11) - opt) / opt)
cm = lambda a: np.cumsum(a) / np.arange(1, len(a) + 1)
cs, cn = cm(ex_s), cm(ex_n)
OUT["CONV"] = dict(final_s=float(cs[-1]), final_n=float(cn[-1]),
                   dev_s={k: float(abs(cs[k - 1] - cs[-1])) for k in (100, 200, 300, 500)},
                   dev_n={k: float(abs(cn[k - 1] - cn[-1])) for k in (100, 200, 300, 500)},
                   curve_s=[float(x) for x in cs[::10]], curve_n=[float(x) for x in cn[::10]])

# ---------------- H. hardware ----------------
cpu = [l.split(":", 1)[1].strip() for l in open("/proc/cpuinfo") if l.startswith("model name")]
mem = [l for l in open("/proc/meminfo") if l.startswith("MemTotal")][0].split()[1]
OUT["HW"] = dict(cpu=cpu[0] if cpu else "unknown", cores=os.cpu_count(), mem_gb=round(int(mem) / 1e6, 1),
                 python=platform.python_version(), numpy=np.__version__)
json.dump(OUT, open("/home/claude/work/results4.json", "w"), indent=1, default=float)
print("done", flush=True)
