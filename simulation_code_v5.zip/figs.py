import json, sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyBboxPatch
sys.path.insert(0, "/home/claude/work")
from model import *

plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.spines.top": False,
                     "axes.spines.right": False, "axes.edgecolor": "#888", "axes.labelcolor": "#222",
                     "xtick.color": "#444", "ytick.color": "#444", "savefig.dpi": 300})
C = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#6250d6"]
R = json.load(open("/home/claude/work/results.json"))

# ---------- Fig 2: layout + case route ----------
def leg(p, q):
    (xs, ys), (xt, yt) = p, q
    if abs(xs - xt) < 1e-9 and on_aisle(xs):
        return [p, q]
    a = CROSS[np.argmin(np.abs(ys - CROSS) + np.abs(CROSS - yt))]
    return [p, (xs, a), (xt, a), q]

fig, ax = plt.subplots(figsize=(6.2, 4.2))
for b, (y0, y1) in enumerate(BLOCKS):
    for i in range(len(AISLES) - 1):
        x0, x1 = AISLES[i] + 1.4, AISLES[i + 1] - 1.4
        if b == 0 and AISLES[i + 1] > 30:
            continue
        ax.add_patch(Rectangle((y0, x0), y1 - y0, x1 - x0, fc="#e9e8e4", ec="#b5b3ab", lw=0.6))
ax.add_patch(Rectangle((PARK[1][0], PARK[0][0]), PARK[1][1] - PARK[1][0], PARK[0][1] - PARK[0][0],
                       fc="none", ec="#999", lw=0.6, ls="--"))
T = {"A": (15, 20.8), "B": (15, 47.6), "C": (45, 47.6), "D": (7.5, 75.4)}
F = {"F1": (35, 5), "F2": (45, 15), "F3": (35, 20)}
route = [F["F2"], T["C"], T["A"], T["B"], T["D"]]
poly = []
for p, q in zip(route[:-1], route[1:]):
    poly += leg(p, q)
xs = [p[1] for p in poly]; ys = [p[0] for p in poly]
ax.plot(xs, ys, color=C[0], lw=2, zorder=3, solid_capstyle="round")
for k, (x, y) in T.items():
    ax.plot(y, x, "s", ms=8, color="#222", mec="white", mew=2, zorder=4)
    ax.text(y + 1.3, x + 1.3, k, fontsize=9, weight="bold", zorder=5)
for k, (x, y) in F.items():
    ax.plot(y, x, "o", ms=8, color=C[1] if k == "F2" else "#bbb", mec="white", mew=2, zorder=4)
    ax.text(y + 1.3, x - 2.6, k, fontsize=8, color="#333", zorder=5)
for i, (x, y) in enumerate(READERS):
    ax.plot(y, x, "^", ms=8, color=C[2], mec="white", mew=1.5, zorder=4, clip_on=False)
    ax.text(y + (1.5 if y < 40 else -6), x + (1.5 if x < 10 else -3.5), f"R{i+1}", fontsize=8, color="#333")
ax.plot(DOCK[1], DOCK[0], "D", ms=7, color=C[3], mec="white", mew=1.5, zorder=4)
ax.text(DOCK[1] + 1.4, DOCK[0] + 0.6, "Dock", fontsize=7, color="#333")
ax.set_xlim(-2, 86); ax.set_ylim(-2, 49.5); ax.set_aspect("equal")
ax.set_xlabel("y (ft) — along picking aisles"); ax.set_ylabel("x (ft)")
fig.tight_layout(); fig.savefig("/home/claude/work/fig2_layout.png"); plt.close(fig)

# ---------- Fig 3: policy excess vs order size ----------
sizes = [4, 6, 8, 10, 12]
pols = ["Random", "S-shape type", "Nearest neighbour", "NN + 2-opt"]
lab = {"Random": "Unsupported (random) sequence", "S-shape type": "Aisle-by-aisle (S-shape-type)",
       "Nearest neighbour": "Nearest neighbour", "NN + 2-opt": "Nearest neighbour + 2-opt"}
fig, ax = plt.subplots(figsize=(6.2, 3.4))
for i, p in enumerate(pols):
    m = [R["sim"][str(n)][p]["excess_pct"] for n in sizes]
    ci = [R["sim"][str(n)][p]["ci"] for n in sizes]
    ax.errorbar(sizes, m, yerr=ci, color=C[i], lw=2, marker="o", ms=5, capsize=2, label=lab[p])
    ax.text(12.25, m[-1], f"{m[-1]:.1f}%", va="center", fontsize=8, color="#333")
ax.axhline(0, color="#999", lw=0.8)
ax.set_xticks(sizes); ax.set_xlim(3.5, 13.6)
ax.set_xlabel("Order size (picks per order)"); ax.set_ylabel("Excess travel over optimum (%)")
ax.grid(axis="y", color="#eee", lw=0.6); ax.legend(frameon=False, fontsize=8, loc="upper left")
fig.tight_layout(); fig.savefig("/home/claude/work/fig3_policies.png"); plt.close(fig)

# ---------- Fig 4: localisation error sensitivity (two panels, one measure each) ----------
sig = sorted(float(s) for s in R["noise"])
nz = {float(k): v for k, v in R["noise"].items()}
fig, axs = plt.subplots(1, 2, figsize=(6.4, 2.9))
axs[0].errorbar(sig, [nz[s]["excess"] for s in sig], yerr=[nz[s]["ci"] for s in sig], color=C[0], lw=2,
                marker="o", ms=5, capsize=2)
axs[0].set_ylabel("Excess travel over optimum (%)"); axs[0].set_title("(a) Route quality", fontsize=9, loc="left")
axs[1].plot(sig, [nz[s]["slot_acc"] for s in sig], color=C[0], lw=2, marker="o", ms=5)
axs[1].set_ylabel("Pick locations correctly identified (%)"); axs[1].set_ylim(0, 105)
axs[1].set_title("(b) Location identification", fontsize=9, loc="left")
case_sig = R["case_loc"]["rmse_nls"] / np.sqrt(2)
for a in axs:
    a.axvline(case_sig, color="#999", ls="--", lw=0.8)
    a.set_xlabel("Positioning error, σ per axis (ft)"); a.grid(axis="y", color="#eee", lw=0.6)
axs[0].text(case_sig + 0.1, axs[0].get_ylim()[1] * 0.92, "pilot\naccuracy", fontsize=7, color="#555", va="top")
fig.tight_layout(); fig.savefig("/home/claude/work/fig4_noise.png"); plt.close(fig)

# ---------- Fig 1: framework ----------
fig, ax = plt.subplots(figsize=(6.4, 3.0)); ax.axis("off"); ax.set_xlim(0, 100); ax.set_ylim(0, 46)
boxes = [
    (2, 26, 20, 16, "Data capture", "HF RFID check-in /\ncheck-out gates;\nUWB tags on pallets\nand forklifts"),
    (27, 26, 20, 16, "Localisation", "UWB ranges →\nleast-squares\nmultilateration →\nslot mapping"),
    (52, 26, 20, 16, "Decision engine", "Forklift assignment +\nexact pick sequencing\n(MTZ model /\nHeld–Karp)"),
    (77, 26, 21, 16, "Execution", "Route issued to\nforklift; database\nupdated at gates\nin real time"),
]
for x, y, w, h, t, s in boxes:
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.4,rounding_size=1.2", fc="#f3f6fb", ec=C[0], lw=1))
    ax.text(x + w / 2, y + h - 2.2, t, ha="center", va="top", fontsize=8.5, weight="bold", color="#13325c")
    ax.text(x + w / 2, y + h - 6.0, s, ha="center", va="top", fontsize=7.2, color="#333", linespacing=1.25)
for x in (22.6, 47.6, 72.6):
    ax.annotate("", xy=(x + 4.0, 34), xytext=(x, 34), arrowprops=dict(arrowstyle="-|>", color="#555", lw=1))
ax.add_patch(FancyBboxPatch((14, 3), 72, 12, boxstyle="round,pad=0.4,rounding_size=1.2", fc="#fbf7ee", ec=C[3], lw=1))
ax.text(50, 12.2, "Warehouse database (stock levels, slot map, forklift states)", ha="center", va="top",
        fontsize=8.2, weight="bold", color="#5a4300")
ax.text(50, 7.6, "read by the decision engine; written by gates and the location service", ha="center",
        va="top", fontsize=7.2, color="#333")
for x in (12, 37, 62, 87.5):
    ax.annotate("", xy=(x if x < 50 else x, 15.8), xytext=(x, 25.3) if x != 62 else (x, 25.3),
                arrowprops=dict(arrowstyle="<|-|>", color="#999", lw=0.8))
fig.tight_layout(); fig.savefig("/home/claude/work/fig1_framework.png"); plt.close(fig)
print("ok")
