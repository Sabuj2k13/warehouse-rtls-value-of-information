"""v3: true multi-block traversal policies (S-shape, largest gap) and a 3D UWB range model."""
import numpy as np
from model2 import Layout, case_layout, scaled_layout, crossings
from model import multilaterate


def _path_len(W):
    """Waypoints are chained so that consecutive points share an aisle (x) or a cross aisle (y)."""
    tot = 0.0
    for (x0, y0), (x1, y1) in zip(W[:-1], W[1:]):
        assert abs(x0 - x1) < 1e-6 or abs(y0 - y1) < 1e-6, (x0, y0, x1, y1)
        tot += abs(x0 - x1) + abs(y0 - y1)
    return tot


def traversal_route(L, idx, start, policy):
    """Multi-block S-shape or largest-gap traversal (after Roodbergen and de Koster, 2001), adapted to a
    route that starts at a forklift position and ends at the dispatch dock.
    1) Enter the pick aisle at the end of the pick-aisle range nearer the start, travel it from the front
       cross aisle to the back of the farthest block containing picks, collecting its picks on the way.
    2) Serve blocks from the farthest to the nearest. S-shape: traverse every pick aisle of the block
       entirely, alternating direction; if the number of aisles is even, the last one is visited by
       return from the front so that the block is left at its front. Largest gap: along the back cross
       aisle visit each aisle's back part by return, traverse the last aisle entirely, then along the
       front cross aisle visit the remaining front parts by return.
    3) From the front of the nearest block travel to the dock.
    Returns total length including the legs start -> entry and exit -> dock (shortest paths)."""
    P = {k: tuple(L.LOCS[i]) for k, i in enumerate(idx)}
    blk = {k: int(L.META[i][0]) for k, i in enumerate(idx)}
    ax_of = {k: P[k][0] for k in P}
    C = L.C
    aisles_all = sorted({ax_of[k] for k in P})
    left, right = aisles_all[0], aisles_all[-1]
    entry = left if L.dist(start, (left, C[0])) <= L.dist(start, (right, C[0])) else right
    toward_right = entry == left
    bmax = max(blk.values())
    W = [(entry, C[0]), (entry, C[bmax + 1])]
    remaining = {k for k in P if ax_of[k] != entry}       # entry aisle picks collected on the way up
    cur_x = entry
    for b in range(bmax, -1, -1):
        yb, yf = C[b + 1], C[b]                             # back and front cross aisle of block b
        ks = [k for k in remaining if blk[k] == b]
        if not ks:
            W += [(cur_x, yf)]                              # pass through the block along the current aisle
            continue
        ais = sorted({ax_of[k] for k in ks})
        if abs(ais[-1] - cur_x) < abs(ais[0] - cur_x):     # sweep away from the current position
            ais = ais[::-1]
        if policy == "S-shape":
            for j, a in enumerate(ais):
                last = j == len(ais) - 1
                if j % 2 == 0:                               # at back -> traverse to front
                    W += [(a, yb), (a, yf)]
                elif not last:                               # at front -> traverse to back
                    W += [(a, yf), (a, yb)]
                else:                                        # even count: return from the front
                    deep = max(P[k][1] for k in ks if ax_of[k] == a)
                    W += [(a, yf), (a, deep), (a, yf)]
            cur_x = W[-1][0]
        else:                                                # largest gap
            fronts = {}
            for j, a in enumerate(ais):
                ys = sorted(P[k][1] for k in ks if ax_of[k] == a)
                if j == len(ais) - 1:
                    W += [(a, yb), (a, yf)]                  # last aisle traversed entirely
                    continue
                pts = [yf] + ys + [yb]
                g = int(np.argmax(np.diff(pts)))             # largest gap between pts[g] and pts[g+1]
                back = [y for y in ys if y > pts[g]]
                front = [y for y in ys if y <= pts[g]]
                if back:
                    W += [(a, yb), (a, min(back)), (a, yb)]
                fronts[a] = front
            for a in ais[:-1][::-1]:
                if fronts.get(a):
                    W += [(a, yf), (a, max(fronts[a])), (a, yf)]
            cur_x = W[-1][0]
    # remove zero-length duplicates
    W2 = [W[0]]
    for w in W[1:]:
        if abs(w[0] - W2[-1][0]) > 1e-9 or abs(w[1] - W2[-1][1]) > 1e-9:
            W2.append(w)
    # chain along cross aisles: consecutive waypoints with different x must share y
    W3 = [W2[0]]
    for w in W2[1:]:
        px, py = W3[-1]
        if abs(px - w[0]) > 1e-9 and abs(py - w[1]) > 1e-9:
            W3.append((w[0], py)) if any(abs(py - c) < 1e-6 for c in C) else W3.append((px, w[1]))
        W3.append(w)
    return L.dist(start, W3[0]) + _path_len(W3) + L.dist(W3[-1], tuple(L.dock)), W3


# ------------------------------------------------------------------ 3D UWB
RACK_H = 13.0       # ft, three pallet levels
LEVELS = (0.8, 5.0, 9.2)   # tag heights of pallets on levels 1-3 (ft)
FORK_TAG_H = 7.5    # roof-mounted forklift tag (ft)


def crossings3d(L, a, p, ns=160):
    """Rack rows whose footprint the 3D segment passes through below rack height."""
    t = np.linspace(0, 1, ns)[:, None]
    pts = a[None, :] * (1 - t) + p[None, :] * t
    R = L.RACKS
    inside = ((pts[:, None, 0] >= R[None, :, 0]) & (pts[:, None, 0] <= R[None, :, 2]) &
              (pts[:, None, 1] >= R[None, :, 1]) & (pts[:, None, 1] <= R[None, :, 3]) &
              (pts[:, None, 2] <= RACK_H))
    # a tag inside its own rack face is not an obstruction by its own row
    return int(inside[:-3].any(axis=0).sum())


def sim_ranges3d(L, anchors3, p3, rng, sig_los, nlos_mean):
    d = np.linalg.norm(anchors3 - p3, axis=1)
    k = np.array([crossings3d(L, a, p3) for a in anchors3])
    bias = np.array([rng.exponential(nlos_mean, kk).sum() if kk > 0 else 0.0 for kk in k])
    return d + rng.normal(0, sig_los, len(d)) + bias, k


def locate2d_from3d(r, anchors3, h_assumed):
    """2D least squares after projecting slant ranges with an assumed tag height."""
    dh = anchors3[:, 2] - h_assumed
    rh = np.sqrt(np.maximum(r ** 2 - dh ** 2, 0.01))
    return multilaterate(rh, anchors3[:, :2])[1]
