import os
HERE = os.path.dirname(os.path.abspath(__file__))
import itertools, json, sys, time
import numpy as np
sys.path.insert(0, HERE)
from model import *

out = {}
# ================= CASE =================
true = {"A": (15., 20.8), "B": (15., 47.6), "C": (45., 47.6), "D": (7.5, 75.4),
        "F1": (35., 5.), "F2": (45., 15.), "F3": (35., 20.)}
ranges = {"A": [25.89, 37.21, 67.21], "B": [50.29, 55.59, 42.08], "C": [63.42, 45.03, 59.25],
          "D": [72.63, 81.87, 11.85], "F1": [35.74, 13.47, 86.59], "F2": [47.40, 14.96, 81.87],
          "F3": [40.02, 23.56, 72.63]}
loc_rows = []
for k, r in ranges.items():
    lin, nls = multilaterate(np.array(r))
    t = np.array(true[k])
    loc_rows.append(dict(obj=k, true=list(t), lin=list(np.round(lin, 2)), nls=list(np.round(nls, 2)),
                         err_lin=round(float(np.linalg.norm(lin - t)), 2),
                         err_nls=round(float(np.linalg.norm(nls - t)), 2),
                         true_ranges=list(np.round(np.linalg.norm(READERS - t, axis=1), 2))))
errs = np.array([r["err_nls"] for r in loc_rows])
rng_res = np.concatenate([np.array(ranges[k]) - np.linalg.norm(READERS - np.array(true[k]), axis=1) for k in ranges])
out["case_loc"] = dict(rows=loc_rows, rmse_nls=round(float(np.sqrt((errs ** 2).mean())), 2),
                       max_nls=round(float(errs.max()), 2), mean_nls=round(float(errs.mean()), 2),
                       range_res_mean=round(float(rng_res.mean()), 2), range_res_sd=round(float(rng_res.std(ddof=1)), 2),
                       range_res_rmse=round(float(np.sqrt((rng_res ** 2).mean())), 2))

items = ["A", "B", "C", "D"]
pts = [true[i] for i in items]
D4 = dmat(pts)
seqs = []
for perm in itertools.permutations(range(4)):
    seqs.append(("".join(items[i] for i in perm), round(sum(D4[perm[i], perm[i + 1]] for i in range(3)), 1)))
seqs.sort(key=lambda s: s[1])
out["case_paths"] = seqs
# joint forklift + sequence (open path, as in the thesis) and closed to dock
allp = pts + [true["F1"], true["F2"], true["F3"], DOCK]
DA = dmat(allp)
joint = []
for fi, f in enumerate(["F1", "F2", "F3"]):
    s = 4 + fi
    best_open = min((route_len(DA, s, list(p)), p) for p in itertools.permutations(range(4)))
    best_dock = min((route_len(DA, s, list(p), 7), p) for p in itertools.permutations(range(4)))
    joint.append(dict(forklift=f, open=round(best_open[0], 1), open_seq="".join(items[i] for i in best_open[1]),
                      first_leg=round(DA[s, best_open[1][0]], 1),
                      dock=round(best_dock[0], 1), dock_seq="".join(items[i] for i in best_dock[1])))
out["case_joint"] = joint
# workers' expected path (thesis Table 15 weights)
w = {"ABDC": .183, "CABD": .214, "CDBA": .191, "DBAC": .22, "DABC": .12, "CBAD": .072}
pd = dict(seqs)
exp = sum(pd[s] * v for s, v in w.items())
out["case_workers"] = dict(expected=round(exp, 2), optimal=seqs[0][1],
                           gap_pct=round(100 * (exp - seqs[0][1]) / exp, 1),
                           share_opt=round(w["CABD"] + w["DBAC"], 3),
                           wsum=round(sum(w.values()), 3))

# ================= SIMULATION =================
rng = np.random.default_rng(20261119)
SIZES = [4, 6, 8, 10, 12]
NINST = 300
nloc = len(LOCS)
out["n_locations"] = nloc
policies = ["Random", "S-shape type", "Nearest neighbour", "NN + 2-opt", "Optimal"]
res = {p: {n: [] for n in SIZES} for p in policies}
assign = {n: [] for n in SIZES}   # nearest-forklift rule vs joint optimum
t_opt = {n: [] for n in SIZES}

def sample_forklifts(k=3):
    return [(rng.uniform(*PARK[0]), rng.uniform(*PARK[1])) for _ in range(k)]

instances = []
for n in SIZES:
    for it in range(NINST):
        idx = rng.choice(nloc, n, replace=False)
        fl = sample_forklifts()
        instances.append((n, idx, fl))
        P = [tuple(LOCS[i]) for i in idx]
        nodes = P + fl + [DOCK]
        D = dmat(nodes)
        picks = list(range(n)); dock = n + 3
        # nearest-forklift rule: forklift closest to its nearest pick
        f_near = min(range(3), key=lambda f: min(D[n + f, k] for k in picks))
        s = n + f_near
        t0 = time.perf_counter()
        opt = held_karp(D, s, picks, dock)
        t_opt[n].append(time.perf_counter() - t0)
        rnd = route_len(D, s, list(rng.permutation(picks)), dock)
        ser = min(route_len(D, s, serpentine(nodes, picks, rv), dock) for rv in (False, True))
        nn = nearest_neighbour(D, s, picks)
        nnl = route_len(D, s, nn, dock)
        nn2 = route_len(D, s, two_opt(D, s, nn, dock), dock)
        for p, v in zip(policies, [rnd, ser, nnl, nn2, opt]):
            res[p][n].append(v)
        jopt = min(held_karp(D, n + f, picks, dock) for f in range(3))
        assign[n].append((opt, jopt))

summary = {}
for n in SIZES:
    o = np.array(res["Optimal"][n])
    row = {}
    for p in policies:
        v = np.array(res[p][n])
        gap = 100 * (v - o) / v   # saving achievable by switching to optimal, % of policy distance
        g2 = 100 * (v - o) / o    # excess over optimal
        row[p] = dict(mean=round(float(v.mean()), 1), sd=round(float(v.std(ddof=1)), 1),
                      excess_pct=round(float(g2.mean()), 1),
                      ci=round(float(1.96 * g2.std(ddof=1) / np.sqrt(len(g2))), 2),
                      share_opt=round(float(np.mean(np.isclose(v, o, atol=1e-6))) * 100, 1))
    a = np.array(assign[n])
    row["assign_gain_pct"] = round(float(np.mean(100 * (a[:, 0] - a[:, 1]) / a[:, 0])), 2)
    row["assign_share_suboptimal"] = round(float(np.mean(a[:, 0] - a[:, 1] > 1e-6)) * 100, 1)
    row["t_opt_ms"] = round(float(np.mean(t_opt[n])) * 1000, 1)
    summary[n] = row
out["sim"] = summary

# Wilcoxon: S-shape type vs optimal, NN vs optimal (paired)
from scipy.stats import wilcoxon
out["wilcoxon"] = {}
for n in SIZES:
    o = np.array(res["Optimal"][n])
    out["wilcoxon"][n] = {p: float(wilcoxon(np.array(res[p][n]), o, zero_method="zsplit").pvalue)
                          for p in ["S-shape type", "Nearest neighbour", "NN + 2-opt"]}

# ILP cross-check on a subsample
chk = []
for (n, idx, fl) in [x for x in instances if x[0] in (6, 8)][:40:4]:
    P = [tuple(LOCS[i]) for i in idx]; nodes = P + fl + [DOCK]; D = dmat(nodes)
    picks = list(range(n)); dock = n + 3
    f_near = min(range(3), key=lambda f: min(D[n + f, k] for k in picks))
    a = held_karp(D, n + f_near, picks, dock); b = mtz_ilp(D, n + f_near, picks, dock)
    chk.append(abs(a - b))
out["ilp_check"] = dict(n=len(chk), max_abs_diff=round(float(max(chk)), 6))

# ================= LOCALISATION NOISE =================
SIG = [0, 0.5, 1, 1.5, 2, 3, 4, 6]
n = 8
noise = {}
sub = [x for x in instances if x[0] == n][:200]
for sg in SIG:
    exc, slot_ok = [], []
    for (_, idx, fl) in sub:
        P = [tuple(LOCS[i]) for i in idx]
        # observed positions -> snap to nearest storage face (Euclidean), forklift kept noisy
        obs_idx = []
        for i in idx:
            o = SLOTS[i] + rng.normal(0, sg, 2)
            obs_idx.append(int(np.argmin(np.linalg.norm(SLOTS - o, axis=1))))
        slot_ok += [a == b for a, b in zip(idx, obs_idx)]
        flo = [(f[0] + rng.normal(0, sg), f[1] + rng.normal(0, sg)) for f in fl]
        Pobs = [tuple(LOCS[i]) for i in obs_idx]
        # plan on observed data
        Dobs = dmat(Pobs + flo + [DOCK])
        picks = list(range(n)); dock = n + 3
        best = None
        for f in range(3):
            seq = held_karp_path(Dobs, n + f, picks, dock)
            l = route_len(Dobs, n + f, seq, dock)
            if best is None or l < best[0]:
                best = (l, f, seq)
        _, f, seq = best
        # execute on true positions
        Dt = dmat(P + fl + [DOCK])
        executed = route_len(Dt, n + f, seq, dock)
        opt = min(held_karp(Dt, n + ff, picks, dock) for ff in range(3))
        exc.append(100 * (executed - opt) / opt)
    noise[sg] = dict(excess=round(float(np.mean(exc)), 2),
                     ci=round(float(1.96 * np.std(exc, ddof=1) / np.sqrt(len(exc))), 2),
                     slot_acc=round(100 * float(np.mean(slot_ok)), 1))
out["noise"] = noise
json.dump(out, open(os.path.join(HERE, "results.json"), "w"), indent=1, default=str)
print(json.dumps({k: out[k] for k in ["case_loc", "case_paths", "case_joint", "case_workers", "ilp_check", "n_locations"]}, indent=0, default=str)[:4000])
print(json.dumps(out["sim"], indent=0)); print(out["noise"]); print(out["wilcoxon"])
