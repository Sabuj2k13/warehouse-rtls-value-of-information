import os
HERE = os.path.dirname(os.path.abspath(__file__))
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.spines.top": False,
                     "axes.spines.right": False, "axes.edgecolor": "#888", "axes.labelcolor": "#222",
                     "xtick.color": "#444", "ytick.color": "#444", "savefig.dpi": 300})
C = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#6250d6"]
R = json.load(open(os.path.join(HERE, "results3.json")))

# Fig 3: excess by policy, order size, storage (small multiples, shared y)
sizes = [4, 6, 8, 10, 12]
pols = ["Random", "S-shape", "Largest gap", "Nearest neighbour", "NN + 2-opt", "Optimal"]
lab = {"Random": "Unsupported (random)", "S-shape": "S-shape (traversal)", "Largest gap": "Largest gap (traversal)",
       "Nearest neighbour": "Nearest neighbour", "NN + 2-opt": "NN + 2-opt", "Optimal": "Optimal route, nearest forklift"}
titles = {"uniform": "(a) Uniform demand", "random": "(b) ABC, random storage", "class": "(c) ABC, class-based storage"}
fig, axs = plt.subplots(1, 3, figsize=(7.2, 3.0), sharey=True)
for a, st in zip(axs, ["uniform", "random", "class"]):
    for i, p in enumerate(pols):
        m = [R["E1"][f"{st}|{n}"][p]["excess"] for n in sizes]
        a.plot(sizes, m, color=C[i], lw=1.8, marker="o", ms=3.5, label=lab[p])
    a.set_title(titles[st], fontsize=8.5, loc="left"); a.set_xticks(sizes)
    a.grid(axis="y", color="#eee", lw=0.6); a.set_xlabel("Order size (lines)")
axs[0].set_ylabel("Excess travel over joint optimum (%)")
h, l = axs[0].get_legend_handles_labels()
fig.legend(h, l, loc="lower center", ncol=3, frameon=False, fontsize=7.5, bbox_to_anchor=(0.5, -0.02))
fig.tight_layout(rect=(0, 0.12, 1, 1)); fig.savefig(os.path.join(HERE, "v3_fig3_policies.png")); plt.close(fig)

# Fig 4: value of joint forklift selection by layout, fleet and placement
keys = [("7x3", "7×3\n(case size)"), ("14x3", "14×3"), ("14x6", "14×6"), ("28x6", "28×6")]
fig, axs = plt.subplots(1, 2, figsize=(7.0, 3.0), sharey=True)
for a, place, ttl in zip(axs, ["staged", "dispersed"], ["(a) Forklifts staged at the front cross aisle", "(b) Forklifts dispersed in the aisles"]):
    x = np.arange(len(keys)); w = 0.36
    for j, kf in enumerate([3, 6]):
        g = [R["E2"][f"{k}|{place}|{kf}"]["gain"] for k, _ in keys]; ci = [R["E2"][f"{k}|{place}|{kf}"]["ci"] for k, _ in keys]
        a.bar(x + (j - 0.5) * (w + 0.02), g, w, yerr=ci, color=C[j], capsize=2, label=f"{kf} forklifts", error_kw=dict(lw=0.8, ecolor="#555"))
        for xi, gi, cc in zip(x + (j - 0.5) * (w + 0.02), g, ci):
            a.text(xi, gi + cc + 0.1, f"{gi:.1f}", ha="center", fontsize=7, color="#333")
    a.set_xticks(x); a.set_xticklabels([k[1] for k in keys], fontsize=8); a.set_title(ttl, fontsize=8.5, loc="left")
    a.grid(axis="y", color="#eee", lw=0.6); a.set_xlabel("Picking aisles × blocks", fontsize=8.5)
axs[0].set_ylabel("Travel saved by joint selection (%)"); axs[0].set_ylim(0, 6.0)
axs[0].legend(frameon=False, fontsize=8, loc="upper left")
fig.tight_layout(); fig.savefig(os.path.join(HERE, "v3_fig4_fleet.png")); plt.close(fig)

# Fig 5: slot identification by anchor configuration, mounting height and NLOS bias
cfg = ["3 corners", "4 corners", "6 (corners + mid-walls)", "8 (perimeter)", "9 (cross-aisle grid)"]
cl = ["3", "4", "6", "8", "9"]
fig, axs = plt.subplots(1, 2, figsize=(7.0, 3.1), sharey=True)
for a, h, ttl in zip(axs, ["low", "ceiling"], ["(a) Anchors at 3.3 ft", "(b) Anchors at 18 ft (above racks)"]):
    x = np.arange(len(cfg)); w = 0.26
    for j, b in enumerate([0.15, 0.3, 0.6]):
        v = [R["E3"][f"{h}|{b}|{c}|NLS"]["slot"] for c in cfg]
        a.bar(x + (j - 1) * (w + 0.02), v, w, color=["#86b6ef", "#2a78d6", "#184f95"][j], label=f"β = {b} ft")
        for xi, vi in zip(x + (j - 1) * (w + 0.02), v):
            a.text(xi, vi + 1.2, f"{vi:.0f}", ha="center", fontsize=6.3, color="#333")
    a.set_xticks(x); a.set_xticklabels(cl); a.set_xlabel("Number of UWB anchors", fontsize=8.5)
    a.set_title(ttl, fontsize=8.5, loc="left"); a.grid(axis="y", color="#eee", lw=0.6)
axs[0].set_ylim(0, 108); axs[0].set_ylabel("Pallets mapped to correct slot (%)")
h_, l_ = axs[0].get_legend_handles_labels()
fig.legend(h_, l_, loc="lower center", ncol=3, frameon=False, fontsize=8, bbox_to_anchor=(0.5, -0.01), title="NLOS bias per rack row crossed", title_fontsize=7.5)
fig.tight_layout(rect=(0, 0.12, 1, 1)); fig.savefig(os.path.join(HERE, "v3_fig5_anchors.png")); plt.close(fig)
print("ok")
