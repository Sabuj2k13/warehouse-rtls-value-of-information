import json, numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "savefig.dpi": 300})
R = json.load(open("results4.json"))["VOI"]
rows = ["Perfect", "Records 2%", "Records 5%", "Records 10%", "UWB (4 anchors)", "UWB (3 anchors)"]
rlab = ["Perfect records", "Records, 2% misplaced", "Records, 5% misplaced", "Records, 10% misplaced", "UWB slot estimate, 4 anchors", "UWB slot estimate, 3 anchors"]
cols = ["Exact", "Stale", "None"]
clab = ["Exact forklift\npositions", "Stale positions\n(half moved)", "No positions\n(rotation dispatch)"]
M = np.array([[R[f"{r}|{c}"]["excess"] for c in cols] for r in rows])
fail = [R[f"{r}|Exact"]["fail_share"] for r in rows]
fig, ax = plt.subplots(figsize=(6.6, 3.4))
im = ax.imshow(M, cmap="Blues", vmin=0, vmax=40, aspect="auto")
for i in range(M.shape[0]):
    for j in range(M.shape[1]):
        ax.text(j, i, f"{M[i,j]:.1f}%", ha="center", va="center", fontsize=8.5, color="white" if M[i, j] > 22 else "#1a1a19")
    ax.text(3.05, i, f"{fail[i]:.1f}%", ha="left", va="center", fontsize=8.5, color="#333")
ax.text(3.05, -0.85, "Wrong-slot\npicks", ha="left", va="center", fontsize=8, color="#333")
ax.set_xticks(range(3)); ax.set_xticklabels(clab, fontsize=8); ax.xaxis.tick_top()
ax.set_yticks(range(len(rows))); ax.set_yticklabels(rlab, fontsize=8)
ax.set_xlim(-0.5, 3.6)
for s in ax.spines.values(): s.set_visible(False)
ax.tick_params(length=0)
cb = fig.colorbar(im, ax=ax, fraction=0.035, pad=0.02); cb.set_label("Excess travel over oracle (%)", fontsize=8); cb.ax.tick_params(labelsize=7.5)
fig.tight_layout(); fig.savefig("v4_fig_voi.png"); plt.close(fig)
print("ok")
