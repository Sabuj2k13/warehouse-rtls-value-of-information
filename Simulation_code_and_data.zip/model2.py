"""v2 models: parametric multi-block layout, demand/storage, routing rules, UWB simulation."""
import itertools
import numpy as np
from model import held_karp, held_karp_path, route_len, nearest_neighbour, two_opt, multilaterate


class Layout:
    """Parallel picking aisles along y (centrelines AISLES), full-width cross aisles at CROSS (y).
    Double-sided rack rows lie between consecutive aisles; blocks lie between consecutive cross aisles."""

    def __init__(self, aisles, cross, bays=8, cross_w=4.0, rack_gap=1.4, park=None, dock=None,
                 skip=lambda b, xr: False):
        self.A = np.asarray(aisles, float)
        self.C = np.asarray(cross, float)
        self.bays = bays
        self.blocks = [(self.C[i] + cross_w / 2, self.C[i + 1] - cross_w / 2) for i in range(len(self.C) - 1)]
        self.park = park
        self.dock = dock if dock is not None else ((self.A[0] + self.A[-1]) / 2, self.C[0])
        acc, slot, meta, racks = [], [], [], []
        for b, (y0, y1) in enumerate(self.blocks):
            bay = (y1 - y0) / bays
            for i in range(len(self.A) - 1):
                xl, xr = self.A[i], self.A[i + 1]
                if skip(b, xr):
                    continue
                racks.append((xl + rack_gap, y0, xr - rack_gap, y1))
                for side, ax, sx in ((+1, xl, xl + rack_gap + 0.6), (-1, xr, xr - rack_gap - 0.6)):
                    for k in range(bays):
                        y = y0 + (k + 0.5) * bay
                        acc.append((ax, y)); slot.append((sx, y)); meta.append((b, int(np.argmin(abs(self.A - ax)))))
        self.LOCS = np.array(acc); self.SLOTS = np.array(slot); self.META = np.array(meta)
        self.RACKS = np.array(racks)
        self.W = self.A[-1] - self.A[0]

    def on_aisle(self, x):
        return bool(np.isclose(self.A, x, atol=1e-6).any())

    def dist(self, p, q):
        (xs, ys), (xt, yt) = p, q
        if abs(xs - xt) < 1e-9 and self.on_aisle(xs):
            return abs(ys - yt)
        return abs(xs - xt) + float(np.min(np.abs(ys - self.C) + np.abs(self.C - yt)))

    def dmat(self, pts):
        n = len(pts); D = np.zeros((n, n))
        for i in range(n):
            for j in range(n):
                if i != j:
                    D[i, j] = self.dist(pts[i], pts[j])
        return D

    def block_of(self, y):
        for b, (y0, y1) in enumerate(self.blocks):
            if y0 - 1e-6 <= y <= y1 + 1e-6:
                return b
        return -1


def case_layout():
    return Layout(aisles=[1.5, 7.5, 15.0, 22.5, 30.0, 37.5, 45.0], cross=[1.4, 26.8, 53.6, 81.4],
                  park=((30.0, 47.5), (3.4, 24.8)), dock=(23.75, 1.4),
                  skip=lambda b, xr: b == 0 and xr > 30.0)


def scaled_layout(n_aisles, n_blocks, block_len=22.4, spacing=7.5):
    aisles = [1.5 + spacing * i for i in range(n_aisles)]
    cross = [1.4 + (block_len + 4.0) * j for j in range(n_blocks + 1)]
    return Layout(aisles=aisles, cross=cross, dock=((aisles[0] + aisles[-1]) / 2, cross[0]))


# ------------------------------------------------------------------ demand & storage
def abc_popularity(n_slots, rng, policy, L):
    """Return pick probability per slot. ABC: 20% of SKUs -> 80% of lines, 30% -> 15%, 50% -> 5%.
    'random' storage spreads classes randomly; 'class' places A nearest the dock, then B, then C."""
    nA, nB = int(0.2 * n_slots), int(0.3 * n_slots)
    nC = n_slots - nA - nB
    w = np.r_[np.full(nA, 0.80 / nA), np.full(nB, 0.15 / nB), np.full(nC, 0.05 / nC)]
    if policy == "random":
        order = rng.permutation(n_slots)
    elif policy == "class":
        dd = np.array([L.dist(tuple(l), L.dock) for l in L.LOCS])
        order = np.argsort(dd + rng.uniform(0, 1e-3, n_slots))   # closest slots first
    else:  # uniform demand
        return np.full(n_slots, 1.0 / n_slots)
    p = np.empty(n_slots); p[order] = w
    return p


def sample_order(n, prob, rng):
    return rng.choice(len(prob), n, replace=False, p=prob)


# ------------------------------------------------------------------ routing rules (sequence based)
def rule_sshape(L, idx, start):
    """Block-wise S-shape-type sequence: blocks from farthest to nearest the dock; within a block,
    pick aisles visited in a sweep whose direction alternates by block (first sweep starts on the
    side nearer the start position); travel direction alternates between consecutive aisles."""
    P = L.LOCS[idx]
    blocks = sorted({L.META[i][0] for i in idx}, reverse=True)
    left_first = abs(start[0] - L.A[0]) <= abs(start[0] - L.A[-1])
    seq, up = [], True    # farthest block is entered from its back, so the first aisle is travelled towards the front
    for bi, b in enumerate(blocks):
        ks = [k for k, i in enumerate(idx) if L.META[i][0] == b]
        aisles = sorted({L.META[idx[k]][1] for k in ks}, reverse=not left_first)
        for a in aisles:
            ak = sorted([k for k in ks if L.META[idx[k]][1] == a], key=lambda k: P[k][1], reverse=up)
            seq += ak; up = not up
        left_first = not left_first
    return seq


def rule_largest_gap(L, idx, start):
    """Largest-gap-type sequence per block (farthest block first): in each aisle the picks are split
    at the largest gap (gaps to the block's front and back cross aisles included); back parts are
    collected on a sweep along the back cross aisle, front parts on the return sweep along the front."""
    P = L.LOCS[idx]
    blocks = sorted({L.META[i][0] for i in idx}, reverse=True)
    left_first = abs(start[0] - L.A[0]) <= abs(start[0] - L.A[-1])
    seq = []
    for b in blocks:
        y0, y1 = L.blocks[b]
        ks = [k for k, i in enumerate(idx) if L.META[i][0] == b]
        aisles = sorted({L.META[idx[k]][1] for k in ks}, reverse=not left_first)
        back, front = [], []
        for a in aisles:
            ak = sorted([k for k in ks if L.META[idx[k]][1] == a], key=lambda k: P[k][1])
            ys = [y0] + [P[k][1] for k in ak] + [y1]
            g = int(np.argmax(np.diff(ys)))
            front.append(ak[:g])            # reached from the front cross aisle
            back.append(ak[g:][::-1])       # reached from the back cross aisle, visited back -> inward
        seq += [k for bk in back for k in bk] + [k for fr in front[::-1] for k in fr]
        left_first = not left_first
    return seq


def all_policies(L, idx, fl, rng, dock=True):
    """Evaluate policies for one order. Benchmarks use the nearest-forklift dispatch rule."""
    n = len(idx)
    pts = [tuple(L.LOCS[i]) for i in idx] + [tuple(f) for f in fl] + [tuple(L.dock)]
    D = L.dmat(pts)
    picks = list(range(n)); end = n + len(fl)
    fnear = min(range(len(fl)), key=lambda f: min(D[n + f, k] for k in picks))
    s = n + fnear
    out = {}
    out["Random"] = route_len(D, s, list(rng.permutation(picks)), end)
    out["S-shape"] = route_len(D, s, rule_sshape(L, idx, fl[fnear]), end)
    out["Largest gap"] = route_len(D, s, rule_largest_gap(L, idx, fl[fnear]), end)
    nn = nearest_neighbour(D, s, picks)
    out["Nearest neighbour"] = route_len(D, s, nn, end)
    out["NN + 2-opt"] = route_len(D, s, two_opt(D, s, nn, end), end)
    out["Optimal"] = held_karp(D, s, picks, end)
    out["Joint optimal"] = min(held_karp(D, n + f, picks, end) for f in range(len(fl)))
    return out


# ------------------------------------------------------------------ UWB simulation
def crossings(L, a, b, ns=120):
    """Number of rack rows intersected by the segment a-b (sampled)."""
    t = np.linspace(0, 1, ns)[:, None]
    pts = a[None, :] * (1 - t) + b[None, :] * t
    R = L.RACKS
    inside = ((pts[:, None, 0] >= R[None, :, 0]) & (pts[:, None, 0] <= R[None, :, 2]) &
              (pts[:, None, 1] >= R[None, :, 1]) & (pts[:, None, 1] <= R[None, :, 3]))
    return int(inside.any(axis=0).sum())


def sim_ranges(L, anchors, p, rng, sig_los, nlos_mean):
    d = np.linalg.norm(anchors - p, axis=1)
    k = np.array([crossings(L, a, p) for a in anchors])
    bias = np.array([rng.exponential(nlos_mean, kk).sum() if kk > 0 else 0.0 for kk in k])
    return d + rng.normal(0, sig_los, len(d)) + bias, k


def robust_multilaterate(r, anchors):
    """NLOS mitigation: with >= 4 anchors, drop the anchor with the largest positive residual
    while that residual exceeds 3 x median absolute residual (at most m-3 drops)."""
    keep = np.ones(len(r), bool)
    _, p = multilaterate(r, anchors)
    for _ in range(len(r) - 3):
        res = r[keep] - np.linalg.norm(anchors[keep] - p, axis=1)
        mad = np.median(np.abs(res)) + 0.15
        j = int(np.argmax(res))
        if res[j] <= 3 * mad:
            break
        idx = np.where(keep)[0][j]; keep[idx] = False
        _, p = multilaterate(r[keep], anchors[keep])
    return p


def anchor_sets(L, Wx=47.5, Ly=84.2):
    c = {"3 corners": [(0, 0), (Wx, 0), (0, Ly)],
         "4 corners": [(0, 0), (Wx, 0), (0, Ly), (Wx, Ly)]}
    c["6 (corners + mid-walls)"] = c["4 corners"] + [(0, Ly / 2), (Wx, Ly / 2)]
    c["8 (perimeter)"] = c["6 (corners + mid-walls)"] + [(Wx / 2, 0), (Wx / 2, Ly)]
    # cross-aisle mounted: anchors above cross aisles (heights ignored) at both side walls and centre
    c["9 (cross-aisle grid)"] = [(x, y) for y in (1.4, 53.6, 81.4) for x in (0, Wx / 2, Wx)]
    return {k: np.array(v, float) for k, v in c.items()}
