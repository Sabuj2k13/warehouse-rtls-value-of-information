import os
HERE = os.path.dirname(os.path.abspath(__file__))
"""v6: dispatching-rule sensitivity of the value of forklift information; absolute savings for break-even."""
import json, sys
import numpy as np
sys.path.insert(0, HERE)
from model3 import *
from model2 import abc_popularity, sample_order, scaled_layout, case_layout
from model import held_karp, held_karp_path, route_len

rng = np.random.default_rng(20261124)

def best_from(L, idx, start):
    n = len(idx); pts = [tuple(L.LOCS[i]) for i in idx] + [start, tuple(L.dock)]
    D = L.dmat(pts); sq = held_karp_path(D, n, list(range(n)), n + 1)
    return sq, route_len(D, n, sq, n + 1)

def exec_len(L, idx, sq, start):
    pts = [start] + [tuple(L.LOCS[idx[k]]) for k in sq] + [tuple(L.dock)]
    return sum(L.dist(pts[i], pts[i + 1]) for i in range(len(pts) - 1))

SCEN = [("7x3 (case)", "class", "dispersed"), ("7x3 (case)", "class", "staged"), ("7x3 (case)", "random", "dispersed"),
        ("14x3", "class", "dispersed"), ("28x6", "class", "dispersed"), ("28x6", "class", "staged")]
RULES_I = ["Joint optimal", "Nearest to any line", "Nearest to first pick", "Nearest to centroid"]
RULES_N = ["Rotation", "Random / first idle"]
OUT = {}; n = 8; NO = 300
for lay, stor, place in SCEN:
    L = case_layout() if lay.startswith("7x3") else scaled_layout(*map(int, lay.split("x")))
    nloc = len(L.LOCS); kf = 6 if lay == "28x6" else 3
    prob = abc_popularity(nloc, rng, stor, L)
    centre = ((L.park[0][0] + L.park[0][1]) / 2, (L.park[1][0] + L.park[1][1]) / 2) if L.park is not None else tuple(L.dock)
    res = {r: [] for r in RULES_I + RULES_N}; ft = {r: [] for r in RULES_I + RULES_N}; optl = []
    for o in range(NO):
        idx = list(sample_order(n, prob, rng))
        if place == "dispersed":
            fl = [tuple(L.LOCS[i]) for i in rng.choice(nloc, kf, replace=False)]
        elif L.park is not None:
            fl = [(rng.uniform(*L.park[0]), rng.uniform(*L.park[1])) for _ in range(kf)]
        else:
            fl = [(rng.uniform(L.A[0], L.A[-1]), L.C[0]) for _ in range(kf)]
        per = [best_from(L, idx, f) for f in fl]; opt = min(x[1] for x in per); optl.append(opt)
        P = [tuple(L.LOCS[i]) for i in idx]; cen = tuple(np.mean(P, axis=0))
        sq0, _ = best_from(L, idx, centre)                                   # plan from the staging centre
        first = P[sq0[0]]
        ch = {"Joint optimal": int(np.argmin([x[1] for x in per])),
              "Nearest to any line": int(np.argmin([min(L.dist(f, q) for q in P) for f in fl])),
              "Nearest to first pick": int(np.argmin([L.dist(f, first) for f in fl])),
              "Nearest to centroid": int(np.argmin([abs(f[0] - cen[0]) + abs(f[1] - cen[1]) for f in fl]))}
        for r, f in ch.items():
            l = per[f][1]; res[r].append(100 * (l - opt) / opt); ft[r].append(l - opt)
        for r, f in [("Rotation", o % kf), ("Random / first idle", int(rng.integers(kf)))]:
            l = exec_len(L, idx, sq0, fl[f]); res[r].append(100 * (l - opt) / opt); ft[r].append(l - opt)
    OUT[f"{lay}|{stor}|{place}"] = {"opt_ft": float(np.mean(optl)),
        **{r: dict(excess=float(np.mean(v)), ci=float(1.96 * np.std(v, ddof=1) / np.sqrt(NO)), ft=float(np.mean(ft[r]))) for r, v in res.items()}}
    print(lay, stor, place, round(np.mean(optl), 1), {r: round(np.mean(v), 1) for r, v in res.items()}, flush=True)
json.dump(OUT, open(os.path.join(HERE, "results6.json"), "w"), indent=1)
