import os
HERE = os.path.dirname(os.path.abspath(__file__))
import json, sys, time
import numpy as np
from scipy.stats import wilcoxon, friedmanchisquare
sys.path.insert(0, HERE)
from model3 import *
from model2 import abc_popularity, sample_order, anchor_sets, robust_multilaterate
from model import held_karp, held_karp_path, route_len, nearest_neighbour, two_opt, multilaterate

rng = np.random.default_rng(20261121)
OUT = {}
L = case_layout(); nloc = len(L.LOCS)
POL = ["Random", "S-shape", "Largest gap", "Nearest neighbour", "NN + 2-opt", "Optimal", "Joint optimal"]

def park():
    return [(rng.uniform(*L.park[0]), rng.uniform(*L.park[1])) for _ in range(3)]

def policies(LL, idx, fl):
    n = len(idx)
    pts = [tuple(LL.LOCS[i]) for i in idx] + [tuple(f) for f in fl] + [tuple(LL.dock)]
    D = LL.dmat(pts); picks = list(range(n)); end = n + len(fl)
    fn = min(range(len(fl)), key=lambda f: min(D[n + f, k] for k in picks)); s = n + fn
    o = {"Random": route_len(D, s, list(rng.permutation(picks)), end),
         "S-shape": traversal_route(LL, idx, fl[fn], "S-shape")[0],
         "Largest gap": traversal_route(LL, idx, fl[fn], "Largest gap")[0]}
    nn = nearest_neighbour(D, s, picks)
    o["Nearest neighbour"] = route_len(D, s, nn, end)
    o["NN + 2-opt"] = route_len(D, s, two_opt(D, s, nn, end), end)
    o["Optimal"] = held_karp(D, s, picks, end)
    o["Joint optimal"] = min(held_karp(D, n + f, picks, end) for f in range(len(fl)))
    return o

# ---------------- E1
t0 = time.time(); SIZES = [4, 6, 8, 10, 12]; NI = 300; STOR = ["uniform", "random", "class"]
E1, raw = {}, {}
for st in STOR:
    prob = abc_popularity(nloc, rng, st, L)
    for n in SIZES:
        rows = [policies(L, sample_order(n, prob, rng), park()) for _ in range(NI)]
        raw[(st, n)] = rows
        o = np.array([r["Joint optimal"] for r in rows]); cell = {}
        for p in POL:
            v = np.array([r[p] for r in rows]); ex = 100 * (v - o) / o
            cell[p] = dict(mean=float(v.mean()), excess=float(ex.mean()), ci=float(1.96 * ex.std(ddof=1) / np.sqrt(len(ex))))
        E1[f"{st}|{n}"] = cell
OUT["E1"] = E1
OUT["wilcoxon_max_p"] = max(float(wilcoxon(np.array([r[p] for r in raw[k]]), np.array([r["Joint optimal"] for r in raw[k]]),
                            zero_method="zsplit").pvalue) for k in raw for p in POL[:-2])
OUT["wilcoxon_rule_vs_joint_max_p"] = max(float(wilcoxon(np.array([r["Optimal"] for r in raw[k]]), np.array([r["Joint optimal"] for r in raw[k]]),
                            zero_method="zsplit").pvalue) for k in raw)
OUT["friedman_max_p"] = max(float(friedmanchisquare(*[np.array([r[p] for r in raw[k]]) for p in POL[:-1]]).pvalue) for k in raw)
print("E1", round(time.time() - t0), flush=True)

# ---------------- E2: forklift placement x layout x fleet
t0 = time.time(); E2 = {}
for na, nb in [(7, 3), (14, 3), (14, 6), (28, 6)]:
    LL = scaled_layout(na, nb)
    for place in ["staged", "dispersed"]:
        for kf in [3, 6]:
            g, ch = [], []
            for _ in range(150):
                idx = rng.choice(len(LL.LOCS), 8, replace=False)
                if place == "dispersed":
                    fl = [tuple(LL.LOCS[i]) for i in rng.choice(len(LL.LOCS), kf, replace=False)]
                else:   # staged along the front cross aisle (e.g. after unloading at the dock)
                    fl = [(rng.uniform(LL.A[0], LL.A[-1]), LL.C[0]) for _ in range(kf)]
                pts = [tuple(LL.LOCS[i]) for i in idx] + fl + [tuple(LL.dock)]
                D = LL.dmat(pts); n = 8; end = n + kf
                fn = min(range(kf), key=lambda f: min(D[n + f, k] for k in range(n)))
                a = held_karp(D, n + fn, list(range(n)), end)
                b = min(held_karp(D, n + f, list(range(n)), end) for f in range(kf))
                g.append(100 * (a - b) / a); ch.append(a - b > 1e-6)
            E2[f"{na}x{nb}|{place}|{kf}"] = dict(gain=float(np.mean(g)), ci=float(1.96 * np.std(g, ddof=1) / np.sqrt(len(g))),
                                                 p95=float(np.percentile(g, 95)), changed=float(100 * np.mean(ch)))
OUT["E2"] = E2
print("E2", round(time.time() - t0), flush=True)

# ---------------- E3: 3D UWB
t0 = time.time(); E3 = {}
AS = anchor_sets(L); prob_c = abc_popularity(nloc, rng, "class", L)
orders = [(sample_order(8, prob_c, rng), park()) for _ in range(120)]
H_ASSUME = 5.0
pal = [(15, 20.8), (15, 47.6), (45, 47.6), (7.5, 75.4)]; fk = [(35, 5), (45, 15), (35, 20)]
for ha, hname in [(3.3, "low"), (18.0, "ceiling")]:
    for beta in [0.15, 0.3, 0.6]:
        for name, A2 in AS.items():
            A3 = np.c_[A2, np.full(len(A2), ha)]
            for est in (["NLS", "Robust"] if len(A2) >= 4 else ["NLS"]):
                def loc(xy, h, hass):
                    r, _ = sim_ranges3d(L, A3, np.array([*xy, h]), rng, 0.33, beta)
                    if est == "NLS":
                        return locate2d_from3d(r, A3, hass)
                    dh = A3[:, 2] - hass; rh = np.sqrt(np.maximum(r ** 2 - dh ** 2, 0.01))
                    return robust_multilaterate(rh, A3[:, :2])
                err, ok = [], []
                for _ in range(2):
                    for i, s in enumerate(L.SLOTS):
                        q = loc(s, rng.choice(LEVELS), H_ASSUME); err.append(np.linalg.norm(q - s))
                        ok.append(int(np.argmin(np.linalg.norm(L.SLOTS - q, axis=1))) == i)
                exc = []
                if beta == 0.3 and est == "NLS":
                    for idx, fl in orders:
                        obs = [int(np.argmin(np.linalg.norm(L.SLOTS - loc(L.SLOTS[i], rng.choice(LEVELS), H_ASSUME), axis=1))) for i in idx]
                        flo = [tuple(loc(f, FORK_TAG_H, FORK_TAG_H)) for f in fl]
                        Dobs = L.dmat([tuple(L.LOCS[i]) for i in obs] + flo + [L.dock]); best = None
                        for f in range(3):
                            sq = held_karp_path(Dobs, 8 + f, list(range(8)), 11); l = route_len(Dobs, 8 + f, sq, 11)
                            if best is None or l < best[0]:
                                best = (l, f, sq)
                        Dt = L.dmat([tuple(L.LOCS[i]) for i in idx] + list(fl) + [L.dock])
                        ex_ = route_len(Dt, 8 + best[1], best[2], 11)
                        opt = min(held_karp(Dt, 8 + f, list(range(8)), 11) for f in range(3))
                        exc.append(100 * (ex_ - opt) / opt)
                # forklift accuracy in the staging zone (for comparison with the pilot)
                fe = [np.linalg.norm(loc(f, FORK_TAG_H, FORK_TAG_H) - np.array(f)) for f in fk for _ in range(60)]
                pe = [np.linalg.norm(loc(s, rng.choice(LEVELS), H_ASSUME) - np.array(s)) for s in pal for _ in range(60)]
                E3[f"{hname}|{beta}|{name}|{est}"] = dict(
                    rmse=float(np.sqrt(np.mean(np.square(err)))), p90=float(np.percentile(err, 90)), slot=float(100 * np.mean(ok)),
                    fork_rmse=float(np.sqrt(np.mean(np.square(fe)))), pilot_pal_rmse=float(np.sqrt(np.mean(np.square(pe)))),
                    excess=float(np.mean(exc)) if exc else None,
                    excess_ci=float(1.96 * np.std(exc, ddof=1) / np.sqrt(len(exc))) if exc else None)
        print(" E3", hname, beta, round(time.time() - t0), flush=True)
OUT["E3"] = E3

# ---------------- speed/throughput sensitivity (from E1, class & random, n = 8)
sA = E1["class|8"]["S-shape"]["mean"] - E1["class|8"]["Joint optimal"]["mean"]
sB = E1["random|8"]["S-shape"]["mean"] - E1["class|8"]["Joint optimal"]["mean"]
OUT["CB"] = dict(saveA=sA, saveB=sB, grid=[dict(v=v, orders=o, hA=o * sA / v * 300 / 3600, hB=o * sB / v * 300 / 3600)
                                           for v in (3.0, 5.0, 7.0) for o in (150, 300, 600)],
                 gate=[dict(cartons=c, sec=s, h=c * s * 300 / 3600) for c in (500, 1500, 3000) for s in (11, 22)])
json.dump(OUT, open(os.path.join(HERE, "results3.json"), "w"), indent=1)
print("done")
