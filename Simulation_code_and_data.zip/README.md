# The value of real-time location data in forklift order picking — code and data

Simulation code, input data and results for the paper "The value of real-time location data in forklift order picking: an RFID/UWB decision framework".

## Contents

| Folder / file | What it is |
|---|---|
| `data/case_layout_parameters.json` | Case warehouse geometry: aisles, cross aisles, blocks, dock, staging zone, rack and tag heights, pilot readers (feet) |
| `data/case_layout_slots.csv` | The 256 pick locations: access point (for routing) and tag position (for localisation) |
| `data/pilot_uwb_ranges.csv`, `data/pilot_uwb_readers.csv` | UWB pilot: surveyed positions of 4 pallets and 3 forklifts, and the ranges recorded at 3 readers (Table 2) |
| `data/pilot_operator_sequence_weights.csv` | Operators' weighted pick sequences for the pilot order (Appendix A) |
| `data/gate_recording_demo_timings.csv` | Gate-recording times from the demonstration trials (Section 4.4) |
| `model.py`, `model2.py`, `model3.py` | Layout and distance model, Held–Karp DP, MILP (HiGHS), heuristics, traversal policies, 2D/3D UWB range model and multilateration |
| `run*.py` | Experiments; each writes the matching `results*.json` |
| `figs*.py` | Figures from the results files |
| `results*.json` | Results reported in the paper |

All other inputs (orders, demand profiles, forklift positions, measurement noise) are generated inside the scripts from fixed random seeds, so every run reproduces the same numbers.

## Where each result comes from

| Paper item | Script → results file |
|---|---|
| Tables 2–3, Appendix A (pilot) | `run.py` → `results.json` |
| Fig. 3, Table 4 (routing policies, storage); Fig. 5 (joint selection); Table 9, Fig. 7 (anchors, 3D UWB); Table 10 (time savings) | `run3.py` → `results3.json` |
| Fig. 4 (value of information); Tables 5–6 (additivity, large orders); pilot bootstrap, β fit, convergence | `run4.py` → `results4.json` |
| Table 7 (robustness), search-time results | `run5.py` → `results5.json` |
| Table 8 (dispatching rules), Table 11 (break-even) | `run6.py` → `results6.json` |
| Fig. 6 (positioning error) | `run.py` → `results.json` |
| Figures | `figs.py` (Figs. 1, 2, 6), `figs3.py` (Figs. 3, 5, 7), `figs4.py` (Fig. 4) |

`run2.py` and `figs2.py` produced intermediate results for an earlier version and are kept for completeness.

## How to run

```bash
pip install -r requirements.txt
python run.py
python run3.py
python run4.py
python run5.py
python run6.py
python figs.py && python figs3.py && python figs4.py
```

Run the scripts from this folder. Times were measured on one core of an Intel Xeon at 2.10 GHz with Python 3.13, numpy 2.5 and scipy 1.18.

## Units

Distances are in feet; times are in seconds unless stated otherwise.

## Licence

MIT (see `LICENSE`).
