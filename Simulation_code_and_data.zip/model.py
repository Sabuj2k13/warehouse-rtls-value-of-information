"""RFID/UWB-enabled order-picking study: case re-analysis + simulation.
Coordinates in feet, frame of the case warehouse (x: 0-47.5, y: 0-84.2)."""
import itertools, json, math
import numpy as np

# ---------------- layout ----------------
W, L = 47.5, 84.2
CROSS = np.array([1.4, 26.8, 53.6, 81.4])          # cross-aisle centrelines (y)
AISLES = np.array([1.5, 7.5, 15.0, 22.5, 30.0, 37.5, 45.0])  # picking-aisle centrelines (x)
BLOCKS = [(3.4, 24.8), (28.8, 51.6), (55.6, 79.4)]  # storage blocks (y ranges)
BAYS = 8
DOCK = (23.75, 1.4)                                 # dispatch / check-out point (assumed)
PARK = ((30.0, 47.5), (3.4, 24.8))                  # forklift parking/staging zone in block 1
READERS = np.array([[0.0, 0.0], [47.5, 0.0], [0.0, 84.2]])


def storage_locations():
    """Pick faces: each double-sided rack row lies between two adjacent aisles;
    a face is reached from its aisle. Block 1 holds only the rows with x < 30."""
    locs = []
    for b, (y0, y1) in enumerate(BLOCKS):
        bay = (y1 - y0) / BAYS
        for ai, ax in enumerate(AISLES):
            # faces reachable from this aisle: rack on left (ai-1..ai) and right (ai..ai+1)
            for side in (-1, 1):
                j = ai + side
                if j < 0 or j >= len(AISLES):
                    continue
                xr = max(ax, AISLES[j])
                if b == 0 and xr > 30.0:
                    continue
                for k in range(BAYS):
                    # access point on aisle centreline; physical slot (tag) 2 ft into the rack face
                    locs.append((ax, y0 + (k + 0.5) * bay, ax + side * 2.0))
    return np.array(locs)


_L = storage_locations()
LOCS = _L[:, :2]                          # access points used for routing
SLOTS = np.c_[_L[:, 2], _L[:, 1]]          # physical tag positions used for localisation


def on_aisle(x):
    return np.isclose(AISLES, x, atol=1e-6).any()


def dist(p, q):
    """Shortest rectilinear travel in a multi-block layout with parallel picking aisles
    (along y) and full-width cross aisles (along x)."""
    (xs, ys), (xt, yt) = p, q
    if abs(xs - xt) < 1e-9 and on_aisle(xs):
        return abs(ys - yt)
    return abs(xs - xt) + float(np.min(np.abs(ys - CROSS) + np.abs(CROSS - yt)))


def dmat(points):
    n = len(points)
    D = np.zeros((n, n))
    for i in range(n):
        for j in range(n):
            if i != j:
                D[i, j] = dist(points[i], points[j])
    return D


# ---------------- routing ----------------
def held_karp(D, start, picks, end=None):
    """Exact shortest Hamiltonian path start -> all picks -> end (end optional).
    D indexed over [start, picks..., end]."""
    n = len(picks)
    INF = 1e18
    dp = np.full((1 << n, n), INF)
    for j in range(n):
        dp[1 << j, j] = D[start, picks[j]]
    P = D[np.ix_(picks, picks)]
    for mask in range(1, 1 << n):
        row = dp[mask]
        if row.min() >= INF:
            continue
        cand = row[:, None] + P                         # from j to k
        best = cand.min(axis=0)
        for k in range(n):
            if mask & (1 << k):
                continue
            nm = mask | (1 << k)
            if best[k] < dp[nm, k]:
                dp[nm, k] = best[k]
    full = (1 << n) - 1
    tail = np.array([D[picks[j], end] if end is not None else 0.0 for j in range(n)])
    return float((dp[full] + tail).min())


def held_karp_path(D, start, picks, end=None):
    """Exact DP with back-pointers (used for n <= 10)."""
    n = len(picks)
    dp = {(1 << j, j): (D[start, picks[j]], None) for j in range(n)}
    for size in range(2, n + 1):
        for comb in itertools.combinations(range(n), size):
            mask = sum(1 << c for c in comb)
            for k in comb:
                pm = mask ^ (1 << k)
                dp[(mask, k)] = min(((dp[(pm, j)][0] + D[picks[j], picks[k]], j) for j in comb if j != k),
                                    key=lambda t: t[0])
    full = (1 << n) - 1
    last = min(range(n), key=lambda j: dp[(full, j)][0] + (D[picks[j], end] if end is not None else 0))
    seq, mask, k = [], full, last
    while k is not None:
        seq.append(picks[k]); prev = dp[(mask, k)][1]; mask ^= (1 << k); k = prev
    return seq[::-1]


def route_len(D, start, seq, end=None):
    tot = D[start, seq[0]] + sum(D[seq[i], seq[i + 1]] for i in range(len(seq) - 1))
    if end is not None:
        tot += D[seq[-1], end]
    return tot


def nearest_neighbour(D, start, picks):
    left, cur, seq = list(picks), start, []
    while left:
        nxt = min(left, key=lambda k: D[cur, k])
        seq.append(nxt); left.remove(nxt); cur = nxt
    return seq


def two_opt(D, start, seq, end=None):
    best, improved = list(seq), True
    bl = route_len(D, start, best, end)
    while improved:
        improved = False
        for i in range(len(best) - 1):
            for j in range(i + 1, len(best)):
                cand = best[:i] + best[i:j + 1][::-1] + best[j + 1:]
                cl = route_len(D, start, cand, end)
                if cl < bl - 1e-9:
                    best, bl, improved = cand, cl, True
    return best


def serpentine(pts, picks, reverse=False):
    """Aisle-by-aisle (S-shape-type) sequence: aisles in increasing (or decreasing) x,
    alternating direction of travel in y."""
    aisles = sorted({pts[k][0] for k in picks}, reverse=reverse)
    seq = []
    for i, ax in enumerate(aisles):
        ks = sorted([k for k in picks if pts[k][0] == ax], key=lambda k: pts[k][1],
                    reverse=(i % 2 == 1))
        seq += ks
    return seq


# ---------------- MTZ ILP check ----------------
def mtz_ilp(D, start, picks, end):
    """MTZ integer programme (Eqs. 5-10) solved with HiGHS via scipy.optimize.milp."""
    from scipy.optimize import milp, LinearConstraint, Bounds
    from scipy.sparse import lil_matrix
    nodes = [start] + list(picks) + [end]
    n = len(picks)
    arcs = [(i, j) for i in nodes for j in nodes
            if i != j and j != start and i != end and not (i == start and j == end)]
    na = len(arcs); nv = na + n
    upos = {k: na + t for t, k in enumerate(picks)}
    c = np.zeros(nv); c[:na] = [D[i, j] for i, j in arcs]
    rows, lb, ub = [], [], []
    def add(coefs, lo, hi):
        rows.append(coefs); lb.append(lo); ub.append(hi)
    add({a: 1 for a, (i, j) in enumerate(arcs) if i == start}, 1, 1)
    add({a: 1 for a, (i, j) in enumerate(arcs) if j == end}, 1, 1)
    for k in picks:
        add({a: 1 for a, (i, j) in enumerate(arcs) if j == k}, 1, 1)
        add({a: 1 for a, (i, j) in enumerate(arcs) if i == k}, 1, 1)
    for a, (s, t) in enumerate(arcs):
        if s in upos and t in upos:
            add({upos[s]: 1, upos[t]: -1, a: n}, -np.inf, n - 1)
    A = lil_matrix((len(rows), nv))
    for r, co in enumerate(rows):
        for v, x in co.items():
            A[r, v] = x
    integ = np.ones(nv); integ[na:] = 0
    lo = np.zeros(nv); hi = np.ones(nv); lo[na:] = 1; hi[na:] = n
    r = milp(c, constraints=LinearConstraint(A.tocsr(), lb, ub), integrality=integ, bounds=Bounds(lo, hi))
    return float(r.fun)


# ---------------- localisation ----------------
def multilaterate(r, anchors=READERS, x0=None):
    """Non-linear least squares (Gauss-Newton) for position from ranges."""
    # linear initial estimate (subtract first equation)
    A = 2 * (anchors[1:] - anchors[0])
    b = (r[0] ** 2 - r[1:] ** 2) + (anchors[1:] ** 2).sum(1) - (anchors[0] ** 2).sum()
    p = np.linalg.lstsq(A, b, rcond=None)[0] if x0 is None else np.array(x0, float)
    p_lin = p.copy()
    for _ in range(50):
        diff = p - anchors
        est = np.linalg.norm(diff, axis=1)
        J = diff / est[:, None]
        step = np.linalg.lstsq(J, r - est, rcond=None)[0]
        p = p + step
        if np.linalg.norm(step) < 1e-9:
            break
    return p_lin, p
